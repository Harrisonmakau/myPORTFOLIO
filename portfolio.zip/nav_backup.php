<?php
// nav.php - Professional Portfolio Navigation Component
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Harrison Makau - Web Developer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;       /* Vibrant blue */
            --primary-dark: #1e40af;
            --secondary: #1e293b;     /* Dark slate */
            --accent: #f59e0b;        /* Golden yellow */
            --light: #f8fafc;
            --dark: #0f172a;
            --success: #10b981;
            --text: #334155;
            --text-light: #64748b;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background-color: var(--light);
            touch-action: manipulation; /* Improve responsiveness on touch devices */
        }
        
        /* Top Info Bar - Modern Developer Style */
       /* Top Info Bar - Modern Developer Style */
.top-info-bar {
    background-color: var(--secondary);
    color: var(--light);
    padding: 5px 0; /* Reduced vertical padding */
    font-size: 0.85rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    font-family: 'Poppins', sans-serif;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1001;
    height: 40px; /* Reduced height for top bar */
    display: flex;
    align-items: center;
}

        .top-info-bar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            width: 100%; /* Ensure container takes full width of parent */
        }
        
        .top-info-bar .info-group {
            display: flex;
            gap: 25px;
        }
        
        .top-info-bar .info-item {
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }
        
        .top-info-bar .info-item:hover {
            color: var(--accent);
        }
        
        .top-info-bar .info-item i {
            margin-right: 8px;
            color: var(--accent);
            font-size: 0.9rem;
        }
        
        .top-info-bar .dev-badge {
            background-color: var(--primary);
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 500;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
        }
        
        .top-info-bar .dev-badge i {
            margin-right: 6px;
            color: white;
        }
        
        /* Side Navigation - Developer Portfolio Style */
        .side-nav {
            width: 280px;
            height: 100vh; /* Set to 100vh initially */
            background: linear-gradient(180deg, var(--secondary) 0%, var(--dark) 100%);
            position: fixed;
            left: 0;
            top: 0;
            z-index: 1000;
            transform: translateX(-100%);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            font-family: 'Poppins', sans-serif;
            display: flex; /* Make side-nav a flex container */
            flex-direction: column; /* Stack children vertically */
        }
        
        .side-nav.open {
            transform: translateX(0);
        }
        
        .side-nav .profile-section {
            padding: 20px 25px 25px; /* Adjust padding to make space for top bar */
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            flex-shrink: 0; /* Prevent shrinking */
            display: flex;
            flex-direction: column;
            align-items: center; /* Center items in profile section */
            padding-top: 80px; /* Space for the fixed top bar */
        }
        
        .side-nav .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: contain; /* Changed to contain to prevent cropping */
            border: 3px solid var(--accent);
            margin-bottom: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: white; /* Add a background color to better see 'contain' effect if image has transparency or is smaller */
        }
        
        .side-nav .profile-name {
            color: white;
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 5px;
            text-align: center;
        }
        
        .side-nav .profile-title {
            color: var(--accent);
            font-size: 0.85rem;
            font-weight: 400;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .side-nav .profile-location {
            color: var(--text-light);
            font-size: 0.8rem;
            display: flex;
            align-items: center;
        }
        
        .side-nav .profile-location i {
            margin-right: 5px;
            color: var(--accent);
            font-size: 0.9rem;
        }

        /* Scrollable navigation content */
        .nav-scrollable-content {
            flex: 1; /* Allows this section to grow and take available space */
            overflow-y: auto; /* Enables vertical scrolling */
            padding-bottom: 15px; /* Add some space before bottom links */
        }

        .side-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .side-nav li {
            position: relative;
        }
        
        .side-nav a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 15px 25px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .side-nav a:hover {
            background-color: rgba(255, 255, 255, 0.05);
            color: white;
            padding-left: 30px;
        }
        
        .side-nav a:hover .nav-icon {
            color: var(--accent);
            transform: scale(1.1);
        }
        
        .side-nav a.active {
            background-color: rgba(37, 99, 235, 0.1);
            color: white;
            border-left: 3px solid var(--accent);
        }
        
        .side-nav a.active .nav-icon {
            color: var(--accent);
        }
        
        .nav-icon {
            margin-right: 15px;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            color: rgba(255, 255, 255, 0.6);
            width: 20px;
            text-align: center;
        }
        
        /* Bottom social links section */
        .side-nav .social-links-bottom {
            flex-shrink: 0; /* Prevent shrinking */
            padding: 15px 25px; /* Consistent padding */
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            background-color: rgba(0, 0, 0, 0.1); /* Subtle background */
            display: flex;
            justify-content: space-around; /* Distribute social icons evenly */
            align-items: center;
        }

        .side-nav .social-links-bottom a {
            color: rgba(255,255,255,0.7);
            font-size: 1.5rem; /* Larger icons for bottom section */
            transition: all 0.3s ease;
            padding: 5px; /* Add padding for easier click/touch target */
        }

        .side-nav .social-links-bottom a:hover {
            color: var(--accent);
            transform: translateY(-3px); /* Subtle lift on hover */
            background-color: transparent; /* Override any background from generic 'a:hover' */
            padding-left: 5px; /* Reset padding-left from generic 'a:hover' */
        }
        
        /* Mobile Toggle Button - Modern Style */
        .nav-toggle {
            position: fixed;
            left: 20px;
            top: 20px;
            background-color: var(--primary);
            color: white;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 1100;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .nav-toggle:hover {
            background-color: var(--primary-dark);
            transform: scale(1.05);
        }
        
        .nav-toggle i {
            font-size: 1.2rem;
            transition: transform 0.3s ease;
        }
        
        .nav-toggle.active i {
            transform: rotate(90deg);
        }
        
        /* Navigation Overlay */
        .nav-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .nav-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        /* Main Content Shift */
        .main-content {
    transition: margin-left 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    margin-left: 0;
    min-height: 100vh;
    box-sizing: border-box;
    padding-top: 0; /* Remove the fixed padding */
}
        .content-below-topbar {
    padding-top: 20px; /* This matches the height of your top bar */
    margin-top: 10px;
}
        .main-content.shifted {
            margin-left: 280px;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 991px) { /* Changed breakpoint to 991px for consistency with common frameworks */
            .top-info-bar .info-group:last-child { /* Hide right info group on smaller screens */
                display: none;
            }

            .top-info-bar .info-item span { /* Hide text for first info group too */
                display: none;
            }

            .top-info-bar .info-item i {
                margin-right: 0;
                font-size: 1rem;
            }
            
            .top-info-bar .dev-badge {
                padding: 3px 6px;
            }

            /* Shift the toggle button to the right of the brand/badge */
            .nav-toggle {
                left: initial; /* Reset left position */
                right: 20px; /* Position on the right */
            }

            .side-nav {
                width: 80%;
                max-width: 300px; /* Limit max width for very large phones/small tablets */
                top: 0; /* Align to top */
            }
            
            .main-content.shifted {
                margin-left: 0; /* Content doesn't shift on mobile, only overlay */
            }
        }
        
        @media (min-width: 992px) {
            .side-nav {
                transform: translateX(0); /* Always open on desktop */
            }
            
            .main-content {
                margin-left: 280px; /* Content shifts for side nav */
            }
            
            .nav-toggle {
                display: none; /* Hide toggle button on desktop */
            }
        }
        
        @media (max-width: 576px) { /* Even smaller screens */
            .top-info-bar .info-group {
                gap: 10px;
            }
            .top-info-bar .dev-badge {
                font-size: 0.7rem;
            }
             .top-info-bar .dev-badge span {
                 display: none; /* Hide text, only show icon on very small screens */
             }
            .top-info-bar .dev-badge i {
                margin-right: 0;
            }
            .top-info-bar .info-item i {
                font-size: 0.85rem;
            }
        }

        /* Animation for Developer Flair */
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }
        
        .dev-float {
            animation: float 3s ease-in-out infinite;
        }
    </style>
</head>
<body>
    
    <div class="top-info-bar">
        <div class="container">
            <div class="info-group">
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Nairobi, Kenya</span>
                </div>
                <div class="info-item">
                    <i class="fas fa-envelope"></i>
                    <span>harrisonmakau343@gmail.com</span>
                </div>
            </div>
            
            <div class="dev-badge">
                <i class="fas fa-code"></i>
                <span>FULL-STACK DEVELOPER</span>
            </div>
            
            <div class="info-group">
                <div class="info-item">
                    <i class="fas fa-phone"></i>
                    <span>+254 769 638 211</span>
                </div>
                <div class="info-item">
                    <i class="fab fa-github"></i>
                    <span>GitHub</span>
                </div>
            </div>
        </div>
    </div>

    <button class="nav-toggle" id="navToggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="nav-overlay" id="navOverlay"></div>
    
    <nav class="side-nav" id="sideNav">
        <div class="profile-section">
            <img src="images/Harrison.jpg" alt="Harrison Makau" class="profile-img dev-float">
            <h2 class="profile-name">Harrison Makau</h2>
            <p class="profile-title">Full-Stack Web Developer</p>
            <div class="profile-location">
                <i class="fas fa-map-marker-alt"></i>
                <span>Nairobi, Kenya</span>
            </div>
        </div>
        
        <div class="nav-scrollable-content">
            <ul>
                <li>
                    <a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-home"></i></span>
                        <span class="nav-text">Home</span>
                    </a>
                </li>
                <li>
                    <a href="about.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-user-tie"></i></span>
                        <span class="nav-text">About Me</span>
                    </a>
                </li>
                <li>
                    <a href="skills.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'skills.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-laptop-code"></i></span>
                        <span class="nav-text">Skills & Tech</span>
                    </a>
                </li>
                <li>
                    <a href="projects.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'projects.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-project-diagram"></i></span>
                        <span class="nav-text">Projects</span>
                        <span style="margin-left: auto; background: var(--accent); color: var(--dark); font-size: 0.7rem; padding: 2px 6px; border-radius: 10px;">5+</span>
                    </a>
                </li>
                <li>
                    <a href="testimonials.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'testimonials.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-quote-left"></i></span>
                        <span class="nav-text">Testimonials</span>
                    </a>
                </li>
                <li>
                    <a href="contact.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-envelope-open-text"></i></span>
                        <span class="nav-text">Contact</span>
                    </a>
                </li>
                <li>
                    <a href="blog.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-blog"></i></span>
                        <span class="nav-text">Developer Blog</span>
                    </a>
                </li>
                 <li>
                    <a href="resume.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'resume.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-file-alt"></i></span>
                        <span class="nav-text">My Resume</span>
                    </a>
                </li>
                <li>
                    <a href="services.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'services.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-cogs"></i></span>
                        <span class="nav-text">Services</span>
                    </a>
                </li>
                <li>
                    <a href="faq.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'faq.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-question-circle"></i></span>
                        <span class="nav-text">FAQ</span>
                    </a>
                </li>
                 <li>
                    <a href="privacy.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'privacy.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-shield-alt"></i></span>
                        <span class="nav-text">Privacy Policy</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="social-links-bottom">
            <a href="https://github.com/Harrisonkamau" target="_blank" title="GitHub Profile">
                <i class="fab fa-github"></i>
            </a>
            <a href="https://linkedin.com/in/harrison-makau" target="_blank" title="LinkedIn Profile">
                <i class="fab fa-linkedin"></i>
            </a>
            <a href="https://twitter.com/HarrisonMakau14" target="_blank" title="Twitter Profile">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="#" title="CodePen Profile">
                <i class="fab fa-codepen"></i>
            </a>
        </div>
    </nav>

    <main class="main-content" id="mainContent">
        </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const sideNav = document.getElementById('sideNav');
            const mainContent = document.getElementById('mainContent');
            const navOverlay = document.getElementById('navOverlay');
            
            // Function to toggle navigation
            function toggleNav() {
                const isOpen = sideNav.classList.contains('open');
                if (isOpen) {
                    sideNav.classList.remove('open');
                    navOverlay.classList.remove('active');
                    navToggle.classList.remove('active');
                    if (window.innerWidth >= 992) {
                        mainContent.classList.remove('shifted');
                    }
                    document.body.style.overflow = ''; // Restore body scrolling
                } else {
                    sideNav.classList.add('open');
                    navOverlay.classList.add('active');
                    navToggle.classList.add('active');
                    if (window.innerWidth >= 992) {
                        mainContent.classList.add('shifted');
                    }
                    document.body.style.overflow = 'hidden'; // Prevent body scrolling when nav is open
                }
            }
            
            navToggle.addEventListener('click', toggleNav);
            
            // Close nav when clicking overlay
            navOverlay.addEventListener('click', toggleNav);
            
            // Close nav when clicking a link on mobile
            // Only attach listener if on mobile initially
            if (window.innerWidth < 992) {
                document.querySelectorAll('.side-nav a').forEach(link => {
                    link.addEventListener('click', function(event) {
                        // Prevent immediate navigation if it's the active link (to avoid re-toggling)
                        if (!this.classList.contains('active')) {
                             toggleNav();
                        } else {
                            // If it's the active link, just close the menu on mobile
                            toggleNav();
                        }
                    });
                });
            }
            
            // Highlight active page
            const currentPage = '<?php echo basename($_SERVER['PHP_SELF']); ?>';
            document.querySelectorAll('.side-nav a').forEach(link => {
                // Check if the link's href (after potential PHP processing) matches the current page.
                // Using startsWith for robustness with potential query parameters later.
                if (link.getAttribute('href') && link.getAttribute('href').startsWith(currentPage)) {
                    link.classList.add('active');
                }
            });
            
            // Responsive adjustments on resize
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 992) {
                    sideNav.classList.add('open'); // Always open on desktop
                    navOverlay.classList.remove('active'); // Hide overlay
                    navToggle.classList.remove('active'); // Deactivate toggle button
                    mainContent.classList.add('shifted'); // Shift content
                    document.body.style.overflow = ''; // Restore body scrolling
                } else {
                    sideNav.classList.remove('open'); // Always closed initially on mobile
                    navOverlay.classList.remove('active'); // Hide overlay
                    navToggle.classList.remove('active'); // Deactivate toggle button
                    mainContent.classList.remove('shifted'); // No content shift on mobile
                    document.body.style.overflow = ''; // Restore body scrolling
                }
            });

            // Initial setup for desktop view if applicable
            if (window.innerWidth >= 992) {
                sideNav.classList.add('open');
                mainContent.classList.add('shifted');
            }
        });
    </script>
</body>
</html>