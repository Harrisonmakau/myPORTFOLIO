<?php
// Configuration and Initialization
require_once 'config.php';
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();

class ContactFormHandler {
    private $conn;
    private $errors = [];
    private $success = false;
    private $inputValues = [
        'name' => '',
        'email' => '',
        'subject' => '',
        'message' => '',
        'rating' => 0,
        'is_public' => 0
    ];

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    public function handleSubmission() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $this->sanitizeInputs();
        $this->validateInputs();

        if (empty($this->errors)) {
            $this->saveToDatabase();
        }
    }

    private function sanitizeInputs() {
        $this->inputValues = [
            'name' => trim($_POST['name'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'subject' => trim($_POST['subject'] ?? ''),
            'message' => trim($_POST['message'] ?? ''),
            'rating' => isset($_POST['rating']) ? (int)$_POST['rating'] : 0,
            'is_public' => isset($_POST['is_public']) ? 1 : 0
        ];
    }

    private function validateInputs() {
        if (empty($this->inputValues['name'])) {
            $this->errors['name'] = "Name is required";
        }

        if (empty($this->inputValues['email'])) {
            $this->errors['email'] = "Email is required";
        } elseif (!filter_var($this->inputValues['email'], FILTER_VALIDATE_EMAIL)) {
            $this->errors['email'] = "Valid email is required";
        }

        if (empty($this->inputValues['subject'])) {
            $this->errors['subject'] = "Subject is required";
        } elseif (strlen($this->inputValues['subject']) > 50) {
            $this->errors['subject'] = "Subject must be 50 characters or less";
        }

        if (empty($this->inputValues['message'])) {
            $this->errors['message'] = "Message is required";
        }
    }

    private function saveToDatabase() {
        try {
            $stmt = $this->conn->prepare(
                "INSERT INTO feedback 
                (name, email, subject, message, rating, is_public) 
                VALUES (?, ?, ?, ?, ?, ?)"
            );
            
            $stmt->bind_param(
                "ssssii",
                $this->inputValues['name'],
                $this->inputValues['email'],
                $this->inputValues['subject'],
                $this->inputValues['message'],
                $this->inputValues['rating'],
                $this->inputValues['is_public']
            );
            
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $this->success = true;
                $this->sendEmailNotification();
            }
            
            $stmt->close();
        } catch (Exception $e) {
            $this->errors['database'] = "Error submitting message: " . $e->getMessage();
        }
    }

    private function sendEmailNotification() {
        $mail = new PHPMailer(true);
        
        try {
            // SMTP Configuration
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'harrisonmakau343@gmail.com';
            $mail->Password   = 'ozcc qkfy enxb kcqq';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = 465;

            // Recipients
            $mail->setFrom($this->inputValues['email'], $this->inputValues['name']);
            $mail->addAddress('harrisonmakau343@gmail.com');
            $mail->addReplyTo($this->inputValues['email'], $this->inputValues['name']);

            // Email Content
            $mail->isHTML(true);
            $mail->Subject = $this->inputValues['subject'];
            $mail->Body    = $this->buildEmailBody();

            $mail->send();
        } catch (Exception $e) {
            $this->errors['email'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }

    private function buildEmailBody() {
        return "
        <html>
        <head>
            <title>New Contact Form Submission</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                h2 { color: #4361ee; }
                p { margin-bottom: 10px; }
                strong { color: #3a0ca3; }
            </style>
        </head>
        <body>
            <h2>New Message from {$this->inputValues['name']}</h2>
            <p><strong>Subject:</strong> {$this->inputValues['subject']}</p>
            <p><strong>Email:</strong> {$this->inputValues['email']}</p>
            <p><strong>Rating:</strong> {$this->inputValues['rating']} stars</p>
            <p><strong>Message:</strong></p>
            <p>{$this->inputValues['message']}</p>
        </body>
        </html>
        ";
    }

    public function getErrors() {
        return $this->errors;
    }

    public function isSuccess() {
        return $this->success;
    }

    public function getInputValue($field) {
        return htmlspecialchars($this->inputValues[$field] ?? '');
    }

    public function isChecked($field, $value) {
        return ($this->inputValues[$field] ?? null) === $value ? 'checked' : '';
    }
}

// Initialize and handle form submission
$contactHandler = new ContactFormHandler($conn);
$contactHandler->handleSubmission();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Harrison Makau | Web Developer</title>
    
    <!-- Assets -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a0ca3;
            --accent: #f72585;
            --secondary: #7209b7;
            --dark: #1a1a2e;
            --light: #f8f9fa;
            --success: #4cc9f0;
            --card-bg: rgba(255, 255, 255, 0.95);
            --text: #14213d;
            --text-light: #6c757d;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light);
            color: var(--text);
            overflow-x: hidden;
            line-height: 1.6;
        }
        
        .floating-tech {
            position: fixed;
            opacity: 0.1;
            z-index: -1;
            animation: float 15s infinite ease-in-out;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
        }
        
        .contact-section {
            padding: 5rem 0;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
        }
        
        .contact-card {
            background: var(--card-bg);
            border-radius: 16px;
            box-shadow: var(--shadow);
            padding: 2.5rem;
            transition: var(--transition);
        }
        
        .contact-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }
        
        .contact-info-item {
            margin-bottom: 1.5rem;
            padding-left: 2rem;
            position: relative;
        }
        
        .contact-info-item i {
            position: absolute;
            left: 0;
            top: 0.2rem;
            color: var(--primary);
            font-size: 1.2rem;
        }
        
        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 2.8rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 1.5rem;
            position: relative;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            border-radius: 2px;
        }
        
        /* Rating stars */
        .rating-container {
            display: flex;
            gap: 10px;
            margin-bottom: 1rem;
        }
        
        .rating-container input[type="radio"] {
            display: none;
        }
        
        .rating-container label {
            font-size: 1.5rem;
            color: #ddd;
            cursor: pointer;
            transition: color 0.3s;
        }
        
        .rating-container input[type="radio"]:checked ~ label,
        .rating-container label:hover,
        .rating-container label:hover ~ label {
            color: var(--accent);
        }
        
        .error-message {
            color: #e63946;
            font-size: 0.9rem;
            margin-top: -1rem;
            margin-bottom: 1rem;
        }
        
        /* Main Container */
        .main-container {
            max-width: 1800px;
            margin: 0 auto 0 280px;
            padding: 0 15px;
            border: 1px solid rgba(67, 97, 238, 0.2);
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 0.7);
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .section-title {
                font-size: 2rem;
            }
            
            .contact-card {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <?php include 'nav.php';?>
        <!-- Floating Tech Elements -->
        <i class="floating-tech fab fa-html5" style="top: 10%; left: 5%; font-size: 3rem; animation-duration: 20s;"></i>
        <i class="floating-tech fab fa-js" style="top: 30%; left: 80%; font-size: 4rem; animation-duration: 25s; animation-delay: 5s;"></i>
        <i class="floating-tech fab fa-css3-alt" style="top: 70%; left: 15%; font-size: 2.5rem; animation-duration: 18s; animation-delay: 3s;"></i>
        <i class="floating-tech fab fa-php" style="top: 60%; left: 70%; font-size: 3.5rem; animation-duration: 22s; animation-delay: 7s;"></i>
        
        <!-- Contact Section -->
        <section class="contact-section">
            <div class="container">
                <div class="text-center mb-5" data-aos="fade-up">
                    <h2 class="section-title">Get In Touch</h2>
                    <p class="text-muted">Have a project in mind or want to discuss opportunities? I'd love to hear from you!</p>
                </div>
                
                <div class="row g-4">
                    <div class="col-lg-6" data-aos="fade-right">
                        <div class="contact-card h-100">
                            <h3 class="mb-4">Contact Information</h3>
                            
                            <div class="contact-info-item">
                                <i class="fas fa-map-marker-alt"></i>
                                <h4>Location</h4>
                                <p>Nairobi, Kenya<br>30075-00100</p>
                            </div>
                            
                            <div class="contact-info-item">
                                <i class="fas fa-envelope"></i>
                                <h4>Email</h4>
                                <p><a href="mailto:harrisonmakau343@gmail.com" class="text-decoration-none">harrisonmakau343@gmail.com</a></p>
                            </div>
                            
                            <div class="contact-info-item">
                                <i class="fas fa-phone-alt"></i>
                                <h4>Phone Numbers</h4>
                                <p>
                                    <a href="tel:+254769638211" class="text-decoration-none">+254 769 638 211</a><br>
                                    <a href="tel:+254716241797" class="text-decoration-none">+254 716 241 797</a>
                                </p>
                            </div>
                            
                            <div class="contact-info-item">
                                <i class="fas fa-clock"></i>
                                <h4>Working Hours</h4>
                                <p>Monday - Friday: 5:30 AM - 1:30 AM<br>Weekends: Available for urgent requests</p>
                            </div>
                            
                            <div class="mt-4">
                                <h4 class="mb-3">Connect With Me</h4>
                                <div class="d-flex flex-wrap gap-2">
                                    <a href="#" class="btn btn-outline-primary btn-sm"><i class="fab fa-linkedin-in me-1"></i> LinkedIn</a>
                                    <a href="#" class="btn btn-outline-primary btn-sm"><i class="fab fa-github me-1"></i> GitHub</a>
                                    <a href="#" class="btn btn-outline-primary btn-sm"><i class="fab fa-twitter me-1"></i> Twitter</a>
                                    <a href="#" class="btn btn-outline-primary btn-sm"><i class="fab fa-whatsapp me-1"></i> WhatsApp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6" data-aos="fade-left">
                        <div class="contact-card">
                            <h3 class="mb-4">Send Me a Message</h3>
                            
                            <?php if ($contactHandler->isSuccess()): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-check-circle me-2"></i> Thank you for your message! I'll get back to you soon.
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($contactHandler->getErrors()['database'])): ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-exclamation-circle me-2"></i> <?= $contactHandler->getErrors()['database'] ?>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" novalidate>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="name" class="form-label">Your Name *</label>
                                        <input type="text" class="form-control" id="name" name="name" 
                                               value="<?= $contactHandler->getInputValue('name') ?>" required>
                                        <?php if (!empty($contactHandler->getErrors()['name'])): ?>
                                            <div class="error-message"><?= $contactHandler->getErrors()['name'] ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label for="email" class="form-label">Your Email *</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="<?= $contactHandler->getInputValue('email') ?>" required>
                                        <?php if (!empty($contactHandler->getErrors()['email'])): ?>
                                            <div class="error-message"><?= $contactHandler->getErrors()['email'] ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="col-12">
                                        <label for="subject" class="form-label">Subject *</label>
                                        <input type="text" class="form-control" id="subject" name="subject"
                                               value="<?= $contactHandler->getInputValue('subject') ?>" required>
                                        <?php if (!empty($contactHandler->getErrors()['subject'])): ?>
                                            <div class="error-message"><?= $contactHandler->getErrors()['subject'] ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="col-12">
                                        <label class="form-label">Your Rating (optional)</label>
                                        <div class="rating-container">
                                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                                <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>"
                                                       <?= $contactHandler->isChecked('rating', $i) ?>>
                                                <label for="star<?= $i ?>">★</label>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <label for="message" class="form-label">Your Message *</label>
                                        <textarea class="form-control" id="message" name="message" rows="5" required><?= $contactHandler->getInputValue('message') ?></textarea>
                                        <?php if (!empty($contactHandler->getErrors()['message'])): ?>
                                            <div class="error-message"><?= $contactHandler->getErrors()['message'] ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="is_public" name="is_public" value="1"
                                                   <?= $contactHandler->isChecked('is_public', 1) ?>>
                                            <label class="form-check-label" for="is_public">
                                                Display my feedback publicly (without personal information)
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary px-4 py-2">
                                            <i class="fas fa-paper-plane me-2"></i> Send Message
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-5">
                    <div class="col-12" data-aos="fade-up">
                        <div class="ratio ratio-16x9 rounded-3 overflow-hidden shadow">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.808477395885!2d36.82115931475392!3d-1.288385835980925!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f10d71b2a3b9d%3A0x1e3b6b1b6b1b6b1b!2sNairobi%2C%20Kenya!5e0!3m2!1sen!2ske!4v1620000000000!5m2!1sen!2ske" allowfullscreen loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Footer -->
        <footer class="bg-dark text-white py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <h5 class="mb-2">Harrison Makau</h5>
                        <p class="mb-0">Full Stack Developer specializing in creating responsive, user-friendly web applications.</p>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <div class="d-flex gap-3 justify-content-md-end mb-2">
                            <a href="#" class="text-white"><i class="fab fa-linkedin-in fa-lg"></i></a>
                            <a href="#" class="text-white"><i class="fab fa-github fa-lg"></i></a>
                            <a href="#" class="text-white"><i class="fab fa-twitter fa-lg"></i></a>
                            <a href="contact.php" class="text-white"><i class="fas fa-envelope fa-lg"></i></a>
                        </div>
                        <p class="mb-0">&copy; <?= date('Y') ?> Harrison Makau. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });
        
        // Form validation enhancement
        document.querySelector('form').addEventListener('submit', function(e) {
            const inputs = this.querySelectorAll('[required]');
            let isValid = true;
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    input.classList.add('is-invalid');
                    isValid = false;
                } else {
                    input.classList.remove('is-invalid');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>