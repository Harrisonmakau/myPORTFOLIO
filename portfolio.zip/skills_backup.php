<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Portfolio - Skills</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <style>
        /* Define your color variables */
        :root {
            --primary-color: #2563eb;   /* Vibrant blue, similar to your existing --primary */
            --primary-color-dark: #1e40af; /* Darker primary for gradients */
            --accent-color: #f59e0b;    /* Golden yellow, similar to your existing --accent */
            --secondary-color: #1e293b; /* Dark slate, similar to your existing --secondary */
            --text-color: #334155;      /* General text color */
            --light-bg: #f8fafc;        /* Light background, similar to your existing --light */
            --grey-light: #e2e8f0;      /* Lighter grey for skill bar background */
        }

        body {
            font-family: 'Poppins', sans-serif; /* Assuming Poppins is used elsewhere, consistent font */
            background-color: var(--light-bg);
            color: var(--text-color);
        }

        /* Base section styling */
        .section-title {
            color: var(--secondary-color);
            font-size: 2.5rem; /* Larger, more impactful title */
            font-weight: 700;
            margin-bottom: 2.5rem; /* Increased space below title */
            position: relative;
            padding-bottom: 0.75rem; /* Space for an underline effect */
        }

        .section-title::after {
            content: '';
            position: absolute;
            left: 50%;
            bottom: 0;
            transform: translateX(-50%);
            width: 80px; /* Short, impactful underline */
            height: 4px;
            background-color: var(--accent-color); /* Accent color underline */
            border-radius: 2px;
        }

        /* Individual skill item styling */
        .skill-item {
            background-color: #ffffff; /* White background for each skill item */
            padding: 1.25rem 1.5rem; /* Generous padding */
            border-radius: 0.75rem; /* Softer rounded corners */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08); /* Subtle, modern shadow */
            transition: transform 0.3s ease, box-shadow 0.3s ease; /* Smooth hover effect */
        }

        .skill-item:hover {
            transform: translateY(-5px); /* Lift effect on hover */
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12); /* Enhanced shadow on hover */
        }

        /* Skill name and percentage alignment */
        .skill-name {
            margin-bottom: 0.75rem; /* Slightly more space below skill name */
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center; /* Vertically align text and percentage */
            color: var(--text-color);
            font-size: 1.05rem; /* Slightly larger font for skill names */
        }

        .skill-icon {
            font-size: 1.2rem; /* Size for the icon */
            color: var(--primary-color); /* Icon color */
        }

        .skill-percentage {
            font-weight: 700; /* Make percentage stand out */
            color: var(--accent-color); /* Use accent color for percentage */
            font-size: 1rem;
        }

        /* Skill bar styling */
        .skill-bar {
            height: 12px; /* Slightly thicker bar for better visibility */
            background-color: var(--grey-light); /* Lighter grey for the empty part of the bar */
            border-radius: 6px; /* Slightly more rounded */
            margin-bottom: 0; /* No margin here, as skill-item has it */
            overflow: hidden;
            position: relative; /* For the subtle inner shadow effect */
        }

        .skill-bar::before { /* Subtle inner shadow on the bar */
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
            border-radius: 6px;
            z-index: 1; /* Ensure it's above the background but below progress */
        }

        .skill-progress {
            height: 100%;
            border-radius: 6px; /* Match parent border-radius */
            background: linear-gradient(90deg, var(--primary-color) 0%, var(--primary-color-dark) 100%); /* Solid gradient for depth */
            position: relative;
            width: 0; /* Starts at 0 for animation */
            transition: width 1.8s ease-out; /* Slightly longer, smoother transition */
            z-index: 2; /* Ensure it's above the inner shadow */
        }

        /* Remove the ::after content from skill-progress as percentage is now in skill-name */
        .skill-progress::after {
            content: none;
        }

        /* Responsive adjustments */
        @media (max-width: 767.98px) {
            .section-title {
                font-size: 2rem;
            }
            .skill-item {
                padding: 1rem 1.25rem;
            }
            .skill-name {
                font-size: 0.95rem;
            }
        }
    </style>
</head>
<body>

    <?php
    $skills = [
        [
            'name' => 'HTML5 (HyperText Markup Language)',
            'percentage' => '95%',
            'icon_class' => 'fab fa-html5' // Specific icon class for HTML5
        ],
        [
            'name' => 'CSS3 (Cascading Style Sheets)',
            'percentage' => '90%',
            'icon_class' => 'fab fa-css3-alt' // Specific icon class for CSS3
        ],
        [
            'name' => 'Bootstrap 5',
            'percentage' => '88%',
            'icon_class' => 'fab fa-bootstrap' // Specific icon class for Bootstrap
        ],
        [
            'name' => 'PHP (Hypertext Preprocessor)',
            'percentage' => '85%',
            'icon_class' => 'fab fa-php' // Specific icon class for PHP
        ],
        [
            'name' => 'MySQL',
            'percentage' => '80%',
            'icon_class' => 'fas fa-database' // Specific icon class for Database (MySQL doesn't have a direct brand icon)
        ],
        [
            'name' => 'JavaScript & jQuery',
            'percentage' => '82%',
            'icon_class' => 'fab fa-js' // Specific icon class for JavaScript
        ]
    ];
    ?>

    <section class="py-5 bg-light" id="skills-section">
        <div class="container">
            <h2 class="text-center section-title animate__animated animate__fadeIn mb-5">Technical Skills</h2>
            <p class="text-center lead mb-5 animate__animated animate__fadeInUp">
                A solid foundation in core web technologies, constantly evolving with industry best practices.
            </p>
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-5">
                    <?php for ($i = 0; $i < 3; $i++): ?>
                        <div class="skill-item mb-4">
                            <div class="skill-name">
                                <span class="skill-icon me-2"><i class="<?= $skills[$i]['icon_class'] ?>"></i></span>
                                <span><?= $skills[$i]['name'] ?></span>
                                <span class="skill-percentage"><?= $skills[$i]['percentage'] ?></span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" data-width="<?= $skills[$i]['percentage'] ?>"></div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
                <div class="col-md-6 col-lg-5">
                    <?php for ($i = 3; $i < 6; $i++): ?>
                        <div class="skill-item mb-4">
                            <div class="skill-name">
                                 <span class="skill-icon me-2"><i class="<?= $skills[$i]['icon_class'] ?>"></i></span>
                                <span><?= $skills[$i]['name'] ?></span>
                                <span class="skill-percentage"><?= $skills[$i]['percentage'] ?></span>
                            </div>
                            <div class="skill-bar">
                                <div class="skill-progress" data-width="<?= $skills[$i]['percentage'] ?>"></div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    $(document).ready(function() {
        // Function to check if an element is in view
        function isElementInView(elem) {
            var docViewTop = $(window).scrollTop();
            var docViewBottom = docViewTop + $(window).height();
            var elemTop = $(elem).offset().top;
            var elemBottom = elemTop + $(elem).height();

            // Add a buffer so animation starts a bit before element is fully in view
            return ((elemBottom <= docViewBottom + 50) && (elemTop >= docViewTop - 50));
        }

        // Handle skill bar animation on scroll
        $(window).on('scroll load', function() { // Added 'load' to trigger on page load
            $('.skill-progress').each(function() {
                // Check if the skill bar is visible and hasn't been animated yet
                if (isElementInView(this) && $(this).data('animated') !== true) {
                    $(this).css('width', $(this).data('width'));
                    $(this).data('animated', true); // Mark as animated
                }
            });
        });

        // Trigger scroll event on load to animate skills already in view
        $(window).trigger('scroll');
    });
    </script>
</body>
</html>