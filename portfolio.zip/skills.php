<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Portfolio - Skills</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a0ca3;
            --accent: #f72585;
            --secondary: #7209b7;
            --dark: #1a1a2e;
            --light: #f8f9fa;
            --success: #4cc9f0;
            --card-bg: rgba(255, 255, 255, 0.9);
            --text: #14213d;
            --text-light: #6c757d;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light);
            color: var(--text);
            overflow-x: hidden;
        }
        
        /* Main container styling */
       .main-container {
    width: 985px;
    margin: 0 auto 0 280px;
    overflow: hidden;
    border: 1px solid rgba(67, 97, 238, 0.15); /* Subtle primary color border */
    box-shadow: 0 0 30px rgba(67, 97, 238, 0.05); /* Very soft glow */
    border-radius: 4px; /* Slight rounding to match your card style */
}
        /* Section Styling */
        .skills-section {
            position: relative;
            padding: 5rem 0;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            overflow: hidden;
        }
        
        .skills-section::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(67, 97, 238, 0.05) 0%, transparent 70%);
            z-index: 0;
            animation: float 15s infinite ease-in-out;
        }
        
        .skills-section::after {
            content: '';
            position: absolute;
            bottom: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(247, 37, 133, 0.05) 0%, transparent 70%);
            z-index: 0;
            animation: float 18s infinite ease-in-out reverse;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0); }
            25% { transform: translate(5%, 5%); }
            50% { transform: translate(10%, 0); }
            75% { transform: translate(5%, -5%); }
        }
        
        /* Title Styling */
        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 3rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 1.5rem;
            position: relative;
            display: inline-block;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            border-radius: 2px;
        }
        
        .section-subtitle {
            font-size: 1.2rem;
            color: var(--text-light);
            margin-bottom: 3rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Skill Card Styling */
        .skill-card {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            z-index: 1;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(10px);
        }
        
        .skill-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
        }
        
        .skill-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .skill-card:hover .skill-icon {
            transform: scale(1.1) rotate(5deg);
            color: var(--accent);
        }
        
        /* Skill Content */
        .skill-header {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .skill-icon {
            font-size: 2.5rem;
            color: var(--primary);
            margin-right: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .skill-name {
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
            color: var(--dark);
        }
        
        .skill-desc {
            font-size: 0.9rem;
            color: var(--text-light);
            font-weight: 400;
        }
        
        /* Progress Bar */
        .progress-container {
            margin-top: 1.5rem;
        }
        
        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .progress-percent {
            color: var(--primary);
            font-weight: 700;
        }
        
        .progress-bar-bg {
            height: 10px;
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 5px;
            overflow: hidden;
            position: relative;
        }
        
        .progress-bar-fill {
            height: 100%;
            border-radius: 5px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            position: relative;
            width: 0;
            transition: width 1.5s cubic-bezier(0.22, 0.61, 0.36, 1);
        }
        
        .progress-bar-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, 
                            rgba(255,255,255,0.3) 0%, 
                            rgba(255,255,255,0) 100%);
            border-radius: 5px;
        }
        
        /* Animation */
        @keyframes cardEntrance {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .skill-card {
            opacity: 0;
            animation: cardEntrance 0.8s forwards;
        }
        
        .skill-card:nth-child(1) { animation-delay: 0.1s; }
        .skill-card:nth-child(2) { animation-delay: 0.2s; }
        .skill-card:nth-child(3) { animation-delay: 0.3s; }
        .skill-card:nth-child(4) { animation-delay: 0.4s; }
        .skill-card:nth-child(5) { animation-delay: 0.5s; }
        .skill-card:nth-child(6) { animation-delay: 0.6s; }
        
        /* Responsive */
        @media (max-width: 992px) {
            .section-title {
                font-size: 2.5rem;
            }
        }
        
        @media (max-width: 768px) {
            .section-title {
                font-size: 2rem;
            }
            
            .skill-card {
                padding: 1.5rem;
            }
            
            .skill-icon {
                font-size: 2rem;
                margin-right: 1rem;
            }
            
            .skill-name {
                font-size: 1.2rem;
            }
        }
        
        /* Floating Elements */
        .floating-elements {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }
        
        .floating-element {
            position: absolute;
            opacity: 0.1;
            animation: floatElement 15s infinite linear;
        }
        
        @keyframes floatElement {
            0% {
                transform: translateY(0) rotate(0deg);
            }
            100% {
                transform: translateY(-100vh) rotate(360deg);
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <?php include 'nav.php'; ?>
        
        <?php
        $skills = [
            [
                'name' => 'HTML5',
                'desc' => 'HyperText Markup Language',
                'percentage' => '95',
                'icon' => 'fab fa-html5',
                'color' => '#e34f26'
            ],
            [
                'name' => 'CSS3',
                'desc' => 'Cascading Style Sheets',
                'percentage' => '90',
                'icon' => 'fab fa-css3-alt',
                'color' => '#2965f1'
            ],
            [
                'name' => 'Bootstrap 5',
                'desc' => 'Front-end framework',
                'percentage' => '88',
                'icon' => 'fab fa-bootstrap',
                'color' => '#7952b3'
            ],
            [
                'name' => 'PHP',
                'desc' => 'Hypertext Preprocessor',
                'percentage' => '85',
                'icon' => 'fab fa-php',
                'color' => '#777bb4'
            ],
            [
                'name' => 'MySQL',
                'desc' => 'Relational database',
                'percentage' => '80',
                'icon' => 'fas fa-database',
                'color' => '#4479a1'
            ],
            [
                'name' => 'JavaScript',
                'desc' => 'Including jQuery',
                'percentage' => '82',
                'icon' => 'fab fa-js-square',
                'color' => '#f7df1e'
            ]
        ];
        ?>

        <section class="skills-section">
            <div class="floating-elements">
                <div class="floating-element" style="top: 10%; left: 5%; font-size: 3rem; animation-duration: 20s;">
                    <i class="fab fa-html5"></i>
                </div>
                <div class="floating-element" style="top: 30%; left: 80%; font-size: 4rem; animation-duration: 25s; animation-delay: 5s;">
                    <i class="fab fa-js-square"></i>
                </div>
                <div class="floating-element" style="top: 70%; left: 15%; font-size: 2.5rem; animation-duration: 18s; animation-delay: 3s;">
                    <i class="fab fa-css3-alt"></i>
                </div>
                <div class="floating-element" style="top: 60%; left: 70%; font-size: 3.5rem; animation-duration: 22s; animation-delay: 7s;">
                    <i class="fab fa-php"></i>
                </div>
            </div>
            
            <div class="container position-relative">
                <div class="text-center mb-5">
                    <h2 class="section-title animate__animated animate__fadeIn">Technical Mastery</h2>
                    <p class="section-subtitle animate__animated animate__fadeIn animate__delay-1s">
                        My expertise spans across modern web technologies, with continuous learning to stay at the forefront of development.
                    </p>
                </div>
                
                <div class="row g-4">
                    <?php foreach ($skills as $skill): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="skill-card">
                            <div class="skill-header">
                                <div class="skill-icon">
                                    <i class="<?= $skill['icon'] ?>" style="color: <?= $skill['color'] ?>"></i>
                                </div>
                                <div>
                                    <h3 class="skill-name"><?= $skill['name'] ?></h3>
                                    <p class="skill-desc"><?= $skill['desc'] ?></p>
                                </div>
                            </div>
                            
                            <div class="progress-container">
                                <div class="progress-label">
                                    <span>Proficiency</span>
                                    <span class="progress-percent"><?= $skill['percentage'] ?>%</span>
                                </div>
                                <div class="progress-bar-bg">
                                    <div class="progress-bar-fill" data-percentage="<?= $skill['percentage'] ?>"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Create more floating elements dynamically
            const floatingContainer = document.querySelector('.floating-elements');
            const icons = ['fa-html5', 'fa-css3-alt', 'fa-js', 'fa-php', 'fa-database', 'fa-code'];
            
            for (let i = 0; i < 8; i++) {
                const element = document.createElement('div');
                element.className = 'floating-element';
                element.innerHTML = `<i class="fab ${icons[Math.floor(Math.random() * icons.length)]}"></i>`;
                
                // Random positioning and animation
                element.style.left = `${Math.random() * 90}%`;
                element.style.top = `${Math.random() * 90}%`;
                element.style.fontSize = `${2 + Math.random() * 3}rem`;
                element.style.animationDuration = `${15 + Math.random() * 15}s`;
                element.style.animationDelay = `${Math.random() * 10}s`;
                element.style.opacity = `${0.05 + Math.random() * 0.1}`;
                
                floatingContainer.appendChild(element);
            }
            
            // Animate progress bars when in view
            const animateProgressBars = () => {
                document.querySelectorAll('.progress-bar-fill').forEach(bar => {
                    const rect = bar.getBoundingClientRect();
                    const isVisible = (rect.top <= window.innerHeight * 0.8) && 
                                      (rect.bottom >= window.innerHeight * 0.2);
                    
                    if (isVisible && !bar.classList.contains('animated')) {
                        bar.style.width = `${bar.dataset.percentage}%`;
                        bar.classList.add('animated');
                    }
                });
            };
            
            // Initial check and scroll event listener
            animateProgressBars();
            window.addEventListener('scroll', animateProgressBars);
            
            // Add hover effect to cards
            document.querySelectorAll('.skill-card').forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.boxShadow = `0 15px 40px rgba(0, 0, 0, 0.15), 0 0 0 2px ${this.querySelector('.skill-icon i').style.color}`;
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.08)';
                });
            });
        });
        </script>
    </div>
</body>
</html>