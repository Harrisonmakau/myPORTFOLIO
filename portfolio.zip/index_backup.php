<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harrison | Full Stack Developer</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --light-color: #f8f9fa;
            --accent-color: #e74c3c;
        }
        body {
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
            scroll-behavior: smooth;
        }
        .hero-section {
    background: linear-gradient(135deg, var(--secondary-color) 0%, #121a24 100%);
    color: white;
    padding: 180px 0 120px;
    position: relative;
    overflow: hidden;
    min-height: 100vh;
    display: flex;
    align-items: center;
}
        .hero-content {
            position: relative;
            z-index: 2;
        }
       .hero-title {
    font-size: 4rem;
    font-weight: 700;
    margin-bottom: 15px;
    line-height: 1.2;
    background: linear-gradient(to right, #fff 0%, var(--primary-color) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
        }
       .hero-subtitle {
    font-size: 1.8rem;
    margin-bottom: 30px;
    font-weight: 400;
    color: rgba(255,255,255,0.9);
}
.text-highlight {
    color: var(--accent-color);
    font-weight: 500;
    position: relative;
    display: inline-block;
}
.text-highlight::after {
    content: '';
    position: absolute;
    bottom: 2px;
    left: 0;
    width: 100%;
    height: 6px;
    background: rgba(231, 76, 60, 0.3);
    z-index: -1;
    border-radius: 3px;
}
.profile-image-container {
    position: relative;
    display: inline-block;
}
      .profile-img-hero {
    width: 100%;
    max-width: 380px;
    height: auto;
    aspect-ratio: 1/1;
    object-fit: cover;
    border: 8px solid rgba(255,255,255,0.1);
    border-radius: 50%;
    box-shadow: 0 25px 50px rgba(0,0,0,0.3);
    transition: all 0.5s ease;
    position: relative;
    z-index: 1; /* Changed from 2 to 1 */
}


       .profile-img-hero:hover {
    transform: scale(1.05) rotate(2deg);
    box-shadow: 0 30px 60px rgba(0,0,0,0.4);
    border-color: rgba(255,255,255,0.2);
}
/* Tech Bubbles Animation */
.tech-bubbles {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 2; /* Changed from 1 to 2 */
}


.bubble {
    position: absolute;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(5px);
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    animation: float 6s infinite ease-in-out;
}

.bubble-1 {
    top: 10%;
    left: 10%;
    animation-delay: 0s;
    background: rgba(52, 152, 219, 0.2);
}

.bubble-2 {
    top: 70%;
    left: 15%;
    animation-delay: 1s;
    background: rgba(155, 89, 182, 0.2);
}

.bubble-3 {
    top: 30%;
    right: 10%;
    animation-delay: 2s;
    background: rgba(241, 196, 15, 0.2);
}

.bubble-4 {
    bottom: 10%;
    right: 15%;
    animation-delay: 3s;
    background: rgba(231, 76, 60, 0.2);
}
        /* Enhanced Button Effects */
.btn-hero {
    position: relative;
    overflow: hidden;
    border: none;
    padding: 15px 35px;
    border-radius: 50px;
    font-weight: 600;
    transition: all 0.4s ease;
    z-index: 1;
}
.btn-hero .btn-content {
    position: relative;
    z-index: 2;
}
.btn-hero .btn-hover-effect {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, 
        rgba(255,255,255,0.1) 0%, 
        rgba(255,255,255,0.3) 100%);
    transform: translateY(100%);
    transition: transform 0.4s ease;
    z-index: 1;
    border-radius: 50px;
}
.btn-hero:hover .btn-hover-effect {
    transform: translateY(0);
}
.btn-primary {
    background: linear-gradient(45deg, var(--primary-color) 0%, #2980b9 100%);
}
.btn-outline-light {
    border: 2px solid rgba(255,255,255,0.3);
    background: transparent;
}
.btn-outline-light:hover {
    background: rgba(255,255,255,0.1);
    border-color: rgba(255,255,255,0.5);
}
/* Trust Indicators */
.trust-indicators {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.1);
}

/* Add this to your CSS */
/* Update the client logo styles */
.clients-logos {
    display: flex;
    align-items: center;
    gap: 20px; /* Add some spacing between logos */
}

.client-logo-container {
    position: relative;
    width: 80px; /* Increased from 50px */
    height: 80px; /* Increased from 50px */
}

.client-logo {
    width: 100%;
    height: 100%;
    object-fit: contain;
    border-radius: 50%;
    padding: 5px; /* Increased from 3px */
    background: white;
    z-index: 2;
    position: relative;
    transition: all 0.3s ease;
    filter: grayscale(100%) brightness(1.5); /* Adjusted for better visibility */
}

.client-logo:hover {
    filter: grayscale(0) brightness(1);
    transform: scale(1.05);
}

.client-logo-border {
    position: absolute;
    top: -5px; /* Increased from -3px */
    left: -5px; /* Increased from -3px */
    right: -5px; /* Increased from -3px */
    bottom: -5px; /* Increased from -3px */
    border-radius: 50%;
    background: linear-gradient(45deg, 
        var(--primary-color), 
        var(--accent-color), 
        #f1c40f, 
        var(--primary-color));
    background-size: 400% 400%;
    animation: spinColors 8s linear infinite;
    z-index: 1;
    filter: blur(4px); /* Slightly reduced blur for better visibility */
}
.clients-logos img {
    transition: all 0.3s ease;
    filter: grayscale(100%) brightness(2);
    opacity: 0.7;
}

.clients-logos img:hover {
    filter: grayscale(0) brightness(1);
    opacity: 1;
    transform: translateY(-3px);
}

/* Typing Animation */
.cursor {
    display: inline-block;
    width: 3px;
    height: 1.2rem;
    background: var(--accent-color);
    margin-left: 5px;
    animation: blink 1s infinite;
}

@keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0; }
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .hero-section {
        padding: 150px 0 80px;
        min-height: auto;
    }
    
    .hero-title {
        font-size: 3rem;
    }
    
    .hero-subtitle {
        font-size: 1.4rem;
    }
}

@media (max-width: 768px) {
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-subtitle {
        font-size: 1.2rem;
    }
    
    .btn-hero {
        padding: 12px 25px;
    }
}
        .btn-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.1);
            z-index: -1;
            transform: scaleX(0);
            transform-origin: right;
            transition: transform 0.4s ease;
        }
        .btn-hero:hover::before {
            transform: scaleX(1);
            transform-origin: left;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-light:hover {
            background-color: rgba(255,255,255,0.1);
        }
        .feature-icon {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .feature-box:hover .feature-icon {
            transform: translateY(-5px) scale(1.1);
            color: var(--accent-color);
        }
        .project-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.4s ease;
            margin-bottom: 30px;
            height: 100%;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
        }
        .project-card::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.7) 100%);
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .project-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        }
        .project-card:hover::after {
            opacity: 1;
        }
        .project-card img {
            height: 200px;
            object-fit: cover;
            width: 100%;
            transition: transform 0.5s ease;
        }
        .project-card:hover img {
            transform: scale(1.05);
        }
        .project-card .card-body {
            position: relative;
            z-index: 2;
        }
        .section-title {
            position: relative;
            display: inline-block;
            margin-bottom: 50px;
            font-weight: 700;
        }
        .section-title:after {
            content: '';
            position: absolute;
            width: 50%;
            height: 4px;
            background: linear-gradient(to right, var(--primary-color), var(--accent-color));
            bottom: -15px;
            left: 25%;
            border-radius: 2px;
        }
       
        .animated-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            opacity: 0.05;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="%23ffffff"><path d="M30,10L50,30L70,10L90,30L70,50L90,70L70,90L50,70L30,90L10,70L30,50L10,30L30,10Z"/></svg>');
        }
        .cta-section {
            background: linear-gradient(135deg, var(--primary-color) 0%, #2980b9 100%);
            color: white;
            padding: 100px 0;
            position: relative;
            overflow: hidden;
        }
        .cta-section::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            top: -50%;
            left: -50%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="%23ffffff" opacity="0.05"><circle cx="25" cy="25" r="20"/><circle cx="75" cy="75" r="20"/></svg>');
            animation: rotate 30s linear infinite;
            z-index: 1;
        }
        .cta-content {
            position: relative;
            z-index: 2;
        }
        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .navbar {
            padding: 20px 0;
            transition: all 0.4s ease;
            background: rgba(44, 62, 80, 0.9) !important;
            backdrop-filter: blur(10px);
        }
        .navbar.scrolled {
            padding: 10px 0;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .nav-link {
            position: relative;
            margin: 0 10px;
            font-weight: 500;
        }
        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background: var(--primary-color);
            bottom: 0;
            left: 0;
            transition: width 0.3s ease;
        }
        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }
        .coming-soon {
            position: absolute;
            top: 15px;
            right: 15px;
            background: var(--accent-color);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
            z-index: 3;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
        }
        .tech-tags .badge {
            margin-right: 5px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .project-card:hover .tech-tags .badge {
            transform: translateY(-3px);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        .footer {
            background: var(--secondary-color);
            color: white;
            padding: 40px 0 20px;
        }
        .social-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            color: white;
            margin-left: 10px;
            transition: all 0.3s ease;
        }
        .social-icon:hover {
            background: var(--primary-color);
            transform: translateY(-3px);
        }
        /* Spinning color elements */
        .color-spin {
            position: absolute;
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.3;
            z-index: 0;
            animation: spin 15s linear infinite;
        }
        .color-spin-1 {
            width: 300px;
            height: 300px;
            background: var(--primary-color);
            top: -100px;
            right: -100px;
            animation-delay: 0s;
        }
        .color-spin-2 {
            width: 400px;
            height: 400px;
            background: var(--accent-color);
            bottom: -150px;
            left: -150px;
            animation-delay: -5s;
        }
        .color-spin-3 {
            width: 200px;
            height: 200px;
            background: #f1c40f;
            top: 50%;
            left: 20%;
            animation-delay: -10s;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
      
        @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
}
    </style>
</head>
<body>
   
   <!-- Hero Section -->
<section class="hero-section">
    <!-- Animated background elements -->
    <div class="animated-bg"></div>
    <div class="color-spin color-spin-1"></div>
    <div class="color-spin color-spin-2"></div>
    
    <!-- Particle.js container (will be added via JS) -->
    <div id="particles-js"></div>
    
    <div class="container">
        <div class="row align-items-center">
            <!-- Text Content -->
            <div class="col-lg-6 hero-content order-lg-1 order-2">
                <!-- Animated greeting text -->
                <div class="greeting-text mb-3 animate__animated animate__fadeInDown">
                    <span class="typed-text"></span><span class="cursor">&nbsp;</span>
                </div>
                
                <h1 class="hero-title animate__animated animate__fadeInDown animate__delay-1s">
                    Harrison Makau
                </h1>
                
                <!-- Professional tagline with animated typing -->
                <p class="hero-subtitle animate__animated animate__fadeInDown animate__delay-2s">
                    <span class="typed-subtitle"></span>
                </p>
                
                <!-- Short bio with highlighted keywords -->
                <div class="hero-bio animate__animated animate__fadeIn animate__delay-3s">
                    <p class="lead mb-4">
                        I craft <span class="text-highlight">scalable web solutions</span> using 
                        <span class="text-highlight">modern technologies</span> with a focus on 
                        <span class="text-highlight">clean code</span> and 
                        <span class="text-highlight">intuitive UX</span>.
                    </p>
                </div>
                
                <!-- Action buttons with hover effects -->
                <div class="hero-actions animate__animated animate__fadeInUp animate__delay-4s">
                    <a href="projects.php" class="btn btn-primary btn-hero me-3 mb-3">
                        <span class="btn-content">
                            <i class="fas fa-eye me-2"></i>View My Work
                        </span>
                        <span class="btn-hover-effect"></span>
                    </a>
                    <a href="contact.php" class="btn btn-outline-light btn-hero mb-3">
                        <span class="btn-content">
                            <i class="fas fa-paper-plane me-2"></i>Hire Me
                        </span>
                        <span class="btn-hover-effect"></span>
                    </a>
                </div>
                
                <!-- Trust indicators -->
               <!-- In your hero section, update the trust indicators -->
<div class="trust-indicators animate__animated animate__fadeIn animate__delay-5s">
    <div class="d-flex align-items-center">
        <div class="trusted-by me-3">
            <span class="badge bg-dark"><i class="fas fa-check-circle me-1"></i> 2+ Projects Delivered</span>
        </div>
        <div class="clients-logos">
            <div class="client-logo-container">
                <div class="client-logo-border"></div>
                <a href="https://www.george-easygari.co.ke"> <img src="images/Screenshot 2025-07-15 220249.png" alt="EasyGari" class="client-logo"></a>
            </div>
            <div class="client-logo-container">
                <div class="client-logo-border"></div>
                <a href="https://harrison.lovestoblog.com"><img src="images/Screenshot 2025-07-15 223138.png" alt="Drive Direct Booking" class="client-logo"></a>
            </div>
        </div>
    </div>
</div>
            </div>
            
            <!-- Profile Image -->
            <div class="col-lg-6 text-center order-lg-2 order-1 mb-4 mb-lg-0 animate__animated animate__fadeIn animate__delay-2s">
                <div class="profile-image-container">
                    <img src="images/Harrison.jpg" alt="Harrison Makau" class="profile-img-hero">
                    <div class="tech-bubbles">
                        <span class="bubble bubble-1"><i class="fab fa-html5"></i></span>
                        <span class="bubble bubble-2"><i class="fab fa-css3-alt"></i></span>
                        <span class="bubble bubble-3"><i class="fab fa-js"></i></span>
                        <span class="bubble bubble-4"><i class="fab fa-php"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- Services Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center section-title animate__animated animate__fadeIn">My Services</h2>
            <div class="row">
                <div class="col-md-4 text-center mb-4 animate__animated animate__fadeInUp">
                    <div class="feature-box p-4 h-100">
                        <div class="feature-icon">
                            <i class="fas fa-laptop-code"></i>
                        </div>
                        <h4>Web Development</h4>
                        <p>Custom websites built with HTML5, CSS3, JavaScript, PHP and MySQL tailored to your requirements.</p>
                    </div>
                </div>
                <div class="col-md-4 text-center mb-4 animate__animated animate__fadeInUp animate__delay-1s">
                    <div class="feature-box p-4 h-100">
                        <div class="feature-icon">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <h4>Responsive Design</h4>
                        <p>Mobile-friendly websites that work perfectly on all devices using Bootstrap framework.</p>
                    </div>
                </div>
                <div class="col-md-4 text-center mb-4 animate__animated animate__fadeInUp animate__delay-2s">
                    <div class="feature-box p-4 h-100">
                        <div class="feature-icon">
                            <i class="fas fa-database"></i>
                        </div>
                        <h4>Database Solutions</h4>
                        <p>Efficient MySQL database systems for dynamic content management and data storage.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="cta-section">
        <div class="color-spin color-spin-3"></div>
        <div class="container text-center cta-content">
            <h2 class="mb-4 animate__animated animate__fadeInDown">Ready to Start Your Project?</h2>
            <p class="lead mb-4 animate__animated animate__fadeIn animate__delay-1s">I'm available for freelance work and full-time opportunities.</p>
            <a href="contact.php" class="btn btn-light btn-lg px-5 py-3 animate__animated animate__fadeInUp animate__delay-2s">Get In Touch <i class="fas fa-paper-plane ms-2"></i></a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 mb-4 mb-md-0">
                    <h5 class="mb-3">Harrison Makau</h5>
                    <p class="mb-0">Full Stack Developer specializing in creating responsive, user-friendly web applications.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="mb-3">
                        <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-github"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                        <a href="contact.php" class="social-icon"><i class="fas fa-envelope"></i></a>
                    </div>
                    <p class="mb-0">&copy; <?php echo date("Y"); ?> Harrison. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Animate skill bars on scroll
        $(document).ready(function() {
            $(window).scroll(function() {
                $('.skill-progress').each(function() {
                    var skillPos = $(this).offset().top;
                    var topOfWindow = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    if (skillPos < topOfWindow + windowHeight - 100) {
                        $(this).css('width', $(this).data('width'));
                    }
                });
            });

            // Navbar scroll effect
            $(window).scroll(function() {
                if ($(this).scrollTop() > 100) {
                    $('.navbar').addClass('scrolled');
                } else {
                    $('.navbar').removeClass('scrolled');
                }
            });

            // Smooth scrolling for anchor links
            $('a[href*="#"]').on('click', function(e) {
                e.preventDefault();
                $('html, body').animate(
                    {
                        scrollTop: $($(this).attr('href')).offset().top - 70,
                    },
                    500,
                    'linear'
                );
            });

            // Trigger scroll event on load
            $(window).trigger('scroll');

            // Add animation classes when elements come into view
            function animateOnScroll() {
                $('.animate__animated').each(function() {
                    var elementPos = $(this).offset().top;
                    var topOfWindow = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    
                    if (elementPos < topOfWindow + windowHeight - 100) {
                        var animationClass = $(this).attr('class').split('animate__animated ')[1].split(' ')[0];
                        $(this).addClass(animationClass);
                    }
                });
            }

            // Run on load and scroll
            animateOnScroll();
            $(window).scroll(function() {
                animateOnScroll();
            });
        });
        <!-- Typed.js for typing animations -->
<script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>

<!-- Particles.js for background effect -->
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>

<script>
    // Initialize Typed.js for greeting text
    new Typed('.typed-text', {
        strings: ["Hello!", "Hola!", "Bonjour!", "Jambo!", "Hi there!"],
        typeSpeed: 100,
        backSpeed: 50,
        loop: true,
        showCursor: false
    });

    // Initialize Typed.js for subtitle
    new Typed('.typed-subtitle', {
        strings: [
            "Full Stack Developer",
            "Web Solutions Architect",
            "BBIT Graduate",
            "Problem Solver"
        ],
        typeSpeed: 60,
        backSpeed: 30,
        loop: true,
        showCursor: false
    });

    // Initialize particles.js
    document.addEventListener('DOMContentLoaded', function() {
        if (document.getElementById('particles-js')) {
            particlesJS('particles-js', {
                "particles": {
                    "number": {
                        "value": 80,
                        "density": {
                            "enable": true,
                            "value_area": 800
                        }
                    },
                    "color": {
                        "value": "#ffffff"
                    },
                    "shape": {
                        "type": "circle",
                        "stroke": {
                            "width": 0,
                            "color": "#000000"
                        }
                    },
                    "opacity": {
                        "value": 0.3,
                        "random": true,
                        "anim": {
                            "enable": true,
                            "speed": 1,
                            "opacity_min": 0.1,
                            "sync": false
                        }
                    },
                    "size": {
                        "value": 3,
                        "random": true,
                        "anim": {
                            "enable": true,
                            "speed": 2,
                            "size_min": 0.1,
                            "sync": false
                        }
                    },
                    "line_linked": {
                        "enable": true,
                        "distance": 150,
                        "color": "#ffffff",
                        "opacity": 0.2,
                        "width": 1
                    },
                    "move": {
                        "enable": true,
                        "speed": 1,
                        "direction": "none",
                        "random": true,
                        "straight": false,
                        "out_mode": "out",
                        "bounce": false,
                        "attract": {
                            "enable": true,
                            "rotateX": 600,
                            "rotateY": 1200
                        }
                    }
                },
                "interactivity": {
                    "detect_on": "canvas",
                    "events": {
                        "onhover": {
                            "enable": true,
                            "mode": "grab"
                        },
                        "onclick": {
                            "enable": true,
                            "mode": "push"
                        },
                        "resize": true
                    },
                    "modes": {
                        "grab": {
                            "distance": 140,
                            "line_linked": {
                                "opacity": 0.5
                            }
                        },
                        "push": {
                            "particles_nb": 4
                        }
                    }
                },
                "retina_detect": true
            });
        }

        // Animate tech bubbles on hover
        const profileImg = document.querySelector('.profile-img-hero');
        if (profileImg) {
            profileImg.addEventListener('mouseenter', () => {
                const bubbles = document.querySelectorAll('.bubble');
                bubbles.forEach((bubble, index) => {
                    bubble.style.transform = `translate(${Math.random() * 20 - 10}px, ${Math.random() * 20 - 10}px)`;
                });
            });
        }
    });
</script>
    </script>
</body>
</html>