<?php
$featuredProjects = [
    [
        'title' => 'EasyGari Agent Portal',
        'description' => 'Professional portal for vehicle financing specialist George Odiwuor featuring loan management and client services.',
        'image' => 'images/Screenshot 2025-07-15 220249.png',
        'technologies' => ['PHP', 'MySQL', 'JavaScript', 'HTML', 'CSS3', 'BootStrap'],
        'link' => 'https://www.george-easygari.co.ke',
        'client' => 'George Odiwuor (EasyGari)',
        'date' => 'July 2025'
    ],
    [
        'title' => 'DriveDirect Booking',
        'description' => 'Final year project featuring a secure bus ticket booking system with admin panel and user management.',
        'image' => 'images/Screenshot 2025-07-15 223138.png',
        'technologies' => ['MySQL', 'JavaScript', 'CSS3', 'PHP'],
        'link' => 'https://harrison.lovestoblog.com',
        'client' => 'Academic Project',
        'date' => 'May 2025'
    ]
];

$upcomingProjects = [
    [
        'title' => 'E-Commerce Platform',
        'description' => 'Full-featured online store with product management, shopping cart, and payment gateway integration.',
        'technologies' => ['React', 'Node.js', 'MongoDB'],
        'status' => 'Development Phase'
    ],
    [
        'title' => 'School Management System',
        'description' => 'Comprehensive system for student records, attendance, exams, and performance tracking.',
        'technologies' => ['Laravel', 'MySQL', 'Vue.js'],
        'status' => 'Planning Phase'
    ],
    [
        'title' => 'Hospital Management System',
        'description' => 'Professional attachment management system for healthcare, ICT, and HR students.',
        'technologies' => ['PHP', 'jQuery', 'HTML5'],
        'status' => 'Design Phase'
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harrison Makau | Professional Portfolio</title>
    
    <!-- Meta tags for SEO and social sharing -->
    <meta name="description" content="Professional portfolio showcasing Harrison Makau's web development projects and technical expertise.">
    <meta name="keywords" content="web developer, full stack developer, PHP, MySQL, JavaScript, portfolio">
    <meta name="author" content="Harrison Makau">
    
    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <!-- AOS (Animate On Scroll) -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a0ca3;
            --accent: #f72585;
            --secondary: #7209b7;
            --dark: #1a1a2e;
            --light: #f8f9fa;
            --success: #4cc9f0;
            --card-bg: rgba(255, 255, 255, 0.95);
            --text: #14213d;
            --text-light: #6c757d;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light);
            color: var(--text);
            overflow-x: hidden;
            line-height: 1.6;
        }
        
        /* Modern Gradient Background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            z-index: -2;
        }
        
        /* Floating Tech Elements */
        .floating-tech {
            position: fixed;
            opacity: 0.1;
            z-index: -1;
            animation: float 15s infinite ease-in-out;
        }
        
        @keyframes float {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            25% { transform: translate(10px, 10px) rotate(5deg); }
            50% { transform: translate(20px, 0) rotate(0deg); }
            75% { transform: translate(10px, -10px) rotate(-5deg); }
        }
        
        /* Section Styling */
        section {
            padding: 5rem 0;
            position: relative;
        }
        
        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 2.8rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 1.5rem;
            position: relative;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            border-radius: 2px;
        }
        
        .section-subtitle {
            font-size: 1.2rem;
            color: var(--text-light);
            margin-bottom: 3rem;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Project Card Styling */
        .project-card {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 0;
            box-shadow: var(--shadow);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            z-index: 1;
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
            height: 100%;
        }
        
        .project-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
        }
        
        .project-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }
        
      .project-image {
    width: 100%;
    max-height: 220px; /* Optional: sets a maximum height */
    object-fit: contain; /* This will show the entire image without cropping */
    transition: transform 0.5s ease;
    border-bottom: 1px solid rgba(0,0,0,0.1); /* Optional: adds a subtle border */
}
        
        .project-card:hover .project-image {
            transform: scale(1.05);
        }
        
        .project-content {
            padding: 1.5rem;
        }
        
        .project-title {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }
        
        .project-description {
            font-size: 0.95rem;
            color: var(--text-light);
            margin-bottom: 1.5rem;
        }
        
        .project-meta {
            font-size: 0.85rem;
            color: var(--text-light);
            margin-bottom: 1rem;
        }
        
        .project-meta span {
            display: block;
            margin-bottom: 0.3rem;
        }
        
        .project-meta i {
            margin-right: 0.5rem;
            color: var(--primary);
        }
        
        .tech-tag {
            display: inline-block;
            background: rgba(67, 97, 238, 0.1);
            color: var(--primary);
            padding: 0.3rem 0.8rem;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            transition: var(--transition);
        }
        
        .project-card:hover .tech-tag {
            background: var(--primary);
            color: white;
            transform: translateY(-3px);
        }
        
        .project-link {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            margin-top: 1rem;
        }
        
        .project-link:hover {
            background: var(--primary-dark);
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        
        .coming-soon-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: var(--accent);
            color: white;
            padding: 0.3rem 1rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 700;
            z-index: 2;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        }
        
        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .section-title {
                font-size: 2.5rem;
            }
        }
        
        @media (max-width: 768px) {
            section {
                padding: 3rem 0;
            }
            
            .section-title {
                font-size: 2rem;
            }
            
            .section-subtitle {
                font-size: 1rem;
            }
        }
        
        /* Wrap Container */
        .wrap-container {
    max-width: 1800px;
    margin: 0 auto 0 280px;
    padding: 0 15px;
    border: 1px solid rgba(67, 97, 238, 0.2); /* Added border with primary color at 20% opacity */
    border-radius: 8px; /* Optional: adds rounded corners to the border */
    background-color: rgba(255, 255, 255, 0.7); /* Optional: adds slight white background to make border more visible */
}
    </style>
</head>
<body>
    <?php include 'nav.php';?>
    <!-- Floating Tech Elements -->
    <i class="floating-tech fab fa-html5" style="top: 10%; left: 5%; font-size: 3rem; animation-duration: 20s;"></i>
    <i class="floating-tech fab fa-js" style="top: 30%; left: 80%; font-size: 4rem; animation-duration: 25s; animation-delay: 5s;"></i>
    <i class="floating-tech fab fa-css3-alt" style="top: 70%; left: 15%; font-size: 2.5rem; animation-duration: 18s; animation-delay: 3s;"></i>
    <i class="floating-tech fab fa-php" style="top: 60%; left: 70%; font-size: 3.5rem; animation-duration: 22s; animation-delay: 7s;"></i>
    
    <!-- Main Content -->
    <div class="wrap-container">
        <div class="container py-5">
            
            <!-- Featured Projects -->
            <section id="featured-projects">
                <div class="text-center mb-5" data-aos="fade-up">
                    <h2 class="section-title">Featured Work</h2>
                    <p class="section-subtitle">Completed projects that demonstrate my capabilities and client satisfaction</p>
                </div>
                
                <div class="row">
                    <?php foreach ($featuredProjects as $project): ?>
                    <div class="col-lg-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="project-card">
                            <img src="<?= $project['image'] ?>" alt="<?= $project['title'] ?>" class="project-image" onerror="this.onerror=null;this.src='https://placehold.co/600x400/cccccc/333333?text=Project+Preview';">
                            <div class="project-content">
                                <h3 class="project-title"><?= $project['title'] ?></h3>
                                <p class="project-description"><?= $project['description'] ?></p>
                                
                                <div class="project-meta">
                                    <span><i class="fas fa-user-tie"></i> <?= $project['client'] ?></span>
                                    <span><i class="fas fa-calendar-alt"></i> <?= $project['date'] ?></span>
                                </div>
                                
                                <div class="tech-tags mb-3">
                                    <?php foreach ($project['technologies'] as $tech): ?>
                                    <span class="tech-tag"><?= $tech ?></span>
                                    <?php endforeach; ?>
                                </div>
                                
                                <a href="<?= $project['link'] ?>" target="_blank" class="project-link">
                                    <i class="fas fa-external-link-alt me-2"></i> View Project
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            
            <!-- Projects in Development -->
            <section id="development-projects" class="bg-light pt-5">
                <div class="text-center mb-5" data-aos="fade-up">
                    <h2 class="section-title">Current Projects</h2>
                    <p class="section-subtitle">Innovative solutions currently in development, showcasing my commitment to continuous learning</p>
                </div>
                
                <div class="row">
                    <?php foreach ($upcomingProjects as $project): ?>
                    <div class="col-lg-4 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="project-card">
                            <div class="position-relative">
                                <img src="https://placehold.co/600x400/e9ecef/6c757d?text=Coming+Soon" alt="<?= $project['title'] ?>" class="project-image">
                                <span class="coming-soon-badge"><?= $project['status'] ?></span>
                            </div>
                            <div class="project-content">
                                <h3 class="project-title"><?= $project['title'] ?></h3>
                                <p class="project-description"><?= $project['description'] ?></p>
                                
                                <div class="tech-tags mb-3">
                                    <?php foreach ($project['technologies'] as $tech): ?>
                                    <span class="tech-tag"><?= $tech ?></span>
                                    <?php endforeach; ?>
                                </div>
                                
                                <a href="#contact" class="project-link">
                                    <i class="fas fa-info-circle me-2"></i> Learn More
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>
            
            <!-- Call to Action -->
            <section class="text-center py-5" data-aos="fade-up">
                <h2 class="mb-4">Ready to Start Your Project?</h2>
                <p class="lead mb-4">I'm available for freelance opportunities and full-time positions.</p>
                <a href="contact.php" class="btn btn-primary btn-lg px-5 py-3">
                    <i class="fas fa-paper-plane me-2"></i> Get In Touch
                </a>
            </section>
        </div>
        
        <!-- Footer -->
        <footer class="bg-dark text-white py-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <h5 class="mb-2">Harrison Makau</h5>
                        <p class="mb-0">Full Stack Developer specializing in creating responsive, user-friendly web applications.</p>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <div class="social-links">
                            <a href="#" class="text-white me-3"><i class="fab fa-linkedin-in fa-lg"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-github fa-lg"></i></a>
                            <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                            <a href="contact.php" class="text-white"><i class="fas fa-envelope fa-lg"></i></a>
                        </div>
                        <p class="mb-0 mt-2">&copy; <?= date('Y') ?> Harrison Makau. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- AOS (Animate On Scroll) -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });
        
        // Add more floating tech elements dynamically
        $(document).ready(function() {
            const techIcons = ['fa-html5', 'fa-css3-alt', 'fa-js', 'fa-php', 'fa-database', 'fa-react', 'fa-node-js'];
            
            for (let i = 0; i < 5; i++) {
                const icon = techIcons[Math.floor(Math.random() * techIcons.length)];
                const size = Math.floor(Math.random() * 3) + 2;
                const duration = Math.floor(Math.random() * 20) + 15;
                const delay = Math.floor(Math.random() * 10);
                const top = Math.floor(Math.random() * 80) + 10;
                const left = Math.floor(Math.random() * 80) + 10;
                
                $('body').append(
                    `<i class="floating-tech fab ${icon}" style="top: ${top}%; left: ${left}%; font-size: ${size}rem; animation-duration: ${duration}s; animation-delay: ${delay}s;"></i>`
                );
            }
        });
    </script>
</body>
</html>