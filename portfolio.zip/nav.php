<?php
// nav.php - Professional Portfolio Navigation Component
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Harrison Makau - Web Developer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        /* Universal box-sizing for consistent layout */
        *, *::before, *::after {
            box-sizing: border-box;
        }

        :root {
            --primary: #2563eb;        /* Vibrant blue */
            --primary-dark: #1e40af;
            --secondary: #1e293b;      /* Dark slate */
            --accent: #f59e0b;         /* Golden yellow */
            --light: #f8fafc;
            --dark: #0f172a;
            --success: #10b981;
            --text: #334155;
            --text-light: #64748b;
        }

        /* Ensure html and body take full height and have no default margins/paddings */
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%; /* Ensures min-height calc works correctly */
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light);
            touch-action: manipulation;
            overflow-x: hidden; /* Prevent horizontal scroll */
            /* KEY CHANGE: Add padding-top to the body to account for the fixed top bar */
            padding-top: 40px; /* Matches the height of .top-info-bar */
        }
        
        /* Top Info Bar - Modern Developer Style */
        .top-info-bar {
            background-color: var(--secondary);
            color: var(--light);
            padding: 5px 0;
            font-size: 0.85rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            font-family: 'Poppins', sans-serif;
            position: fixed; /* Stays at the top */
            top: 0;
            left: 0;
            right: 0;
            z-index: 1001; /* Higher z-index to be on top of other content */
            height: 40px; /* Explicit height */
            display: flex;
            align-items: center;
            box-sizing: border-box;
        }

        .top-info-bar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            width: 100%;
        }
        
        .top-info-bar .info-group {
            display: flex;
            gap: 25px;
        }
        
        .top-info-bar .info-item {
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }
        
        .top-info-bar .info-item:hover {
            color: var(--accent);
        }
        
        .top-info-bar .info-item i {
            margin-right: 8px;
            color: var(--accent);
            font-size: 0.9rem;
        }
        
        .top-info-bar .dev-badge {
            background-color: var(--primary);
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 500;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
        }
        
        .top-info-bar .dev-badge i {
            margin-right: 6px;
            color: white;
        }
        
        /* Side Navigation - Developer Portfolio Style */
        .side-nav {
            width: 280px;
            height: 100vh; /* Full viewport height */
            background: linear-gradient(180deg, var(--secondary) 0%, var(--dark) 100%);
            position: fixed;
            left: 0;
            top: 0; /* Aligned to the very top */
            z-index: 1000;
            transform: translateX(-100%);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            font-family: 'Poppins', sans-serif;
            display: flex;
            flex-direction: column;
        }
        
        .side-nav.open {
            transform: translateX(0);
        }
        
        .side-nav .profile-section {
            padding: 20px 25px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            /* Adjusted padding-top to account for the fixed top-info-bar */
            padding-top: 60px; /* 40px for top bar + 20px internal padding */
        }
        
        .side-nav .profile-img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: contain;
            border: 3px solid var(--accent);
            margin-bottom: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: white;
        }
        
        .side-nav .profile-name {
            color: white;
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 5px;
            text-align: center;
        }
        
        .side-nav .profile-title {
            color: var(--accent);
            font-size: 0.85rem;
            font-weight: 400;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .side-nav .profile-location {
            color: var(--text-light);
            font-size: 0.8rem;
            display: flex;
            align-items: center;
        }
        
        .side-nav .profile-location i {
            margin-right: 5px;
            color: var(--accent);
            font-size: 0.9rem;
        }

        /* Scrollable navigation content */
        .nav-scrollable-content {
            flex: 1;
            overflow-y: auto;
            padding-bottom: 15px;
        }

        .side-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .side-nav li {
            position: relative;
        }
        
        .side-nav a {
            display: flex;
            align-items: center;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 15px 25px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .side-nav a:hover {
            background-color: rgba(255, 255, 255, 0.05);
            color: white;
            padding-left: 30px;
        }
        
        .side-nav a:hover .nav-icon {
            color: var(--accent);
            transform: scale(1.1);
        }
        
        .side-nav a.active {
            background-color: rgba(37, 99, 235, 0.1);
            color: white;
            border-left: 3px solid var(--accent);
        }
        
        .side-nav a.active .nav-icon {
            color: var(--accent);
        }
        
        .nav-icon {
            margin-right: 15px;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            color: rgba(255, 255, 255, 0.6);
            width: 20px;
            text-align: center;
        }
        
        /* Bottom social links section */
        .side-nav .social-links-bottom {
            flex-shrink: 0;
            padding: 15px 25px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            background-color: rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .side-nav .social-links-bottom a {
            color: rgba(255,255,255,0.7);
            font-size: 1.5rem;
            transition: all 0.3s ease;
            padding: 5px;
        }

        .side-nav .social-links-bottom a:hover {
            color: var(--accent);
            transform: translateY(-3px);
            background-color: transparent;
            padding-left: 5px;
        }
        
        /* Mobile Toggle Button - Modern Style */
        .nav-toggle {
            position: fixed;
            left: 20px;
            top: 10px; /* Position relative to the viewport, not main content */
            background-color: var(--primary);
            color: white;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 1100;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .nav-toggle:hover {
            background-color: var(--primary-dark);
            transform: scale(1.05);
        }
        
        .nav-toggle i {
            font-size: 1.2rem;
            transition: transform 0.3s ease;
        }
        
        .nav-toggle.active i {
            transform: rotate(90deg);
        }
        
        /* Navigation Overlay */
        .nav-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .nav-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
      
        /* Responsive Adjustments */
        @media (max-width: 991px) {
            .top-info-bar .info-group:last-child {
                display: none;
            }

            .top-info-bar .info-item span {
                display: none;
            }

            .top-info-bar .info-item i {
                margin-right: 0;
                font-size: 1rem;
            }
            
            .top-info-bar .dev-badge {
                padding: 3px 6px;
            }

            .nav-toggle {
                left: initial;
                right: 20px;
            }

            .side-nav {
                width: 80%;
                max-width: 300px;
                top: 0;
            }
            
            .main-content.shifted {
                margin-left: 0;
            }
        }
        
        @media (min-width: 992px) {
            .side-nav {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 280px;
            }
            
            .nav-toggle {
                display: none;
            }
        }
        
        @media (max-width: 576px) {
            .top-info-bar .info-group {
                gap: 10px;
            }
            .top-info-bar .dev-badge {
                font-size: 0.7rem;
            }
             .top-info-bar .dev-badge span {
                 display: none;
             }
            .top-info-bar .dev-badge i {
                margin-right: 0;
            }
            .top-info-bar .info-item i {
                font-size: 0.85rem;
            }
        }

        /* Animation for Developer Flair */
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }
        
        .dev-float {
            animation: float 3s ease-in-out infinite;
        }
    </style>
</head>
<body>
    
    <div class="top-info-bar">
        <div class="container">
            <div class="info-group">
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Nairobi, Kenya</span>
                </div>
                <div class="info-item">
                    <i class="fas fa-envelope"></i>
                    <span>harrisonmakau343@gmail.com</span>
                </div>
            </div>
            
            <div class="dev-badge">
                <i class="fas fa-code"></i>
                <span>FULL-STACK DEVELOPER</span>
            </div>
            
            <div class="info-group">
                <div class="info-item">
                    <i class="fas fa-phone"></i>
                    <span>+254 769 638 211</span>
                </div>
                <div class="info-item">
                    <i class="fab fa-github"></i>
                    <span>GitHub</span>
                </div>
            </div>
        </div>
    </div>

    <button class="nav-toggle" id="navToggle">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="nav-overlay" id="navOverlay"></div>
    
    <nav class="side-nav" id="sideNav">
        <div class="profile-section">
            <img src="images/Harrison.jpg" alt="Harrison Makau" class="profile-img dev-float">
            <h2 class="profile-name">Harrison Makau</h2>
            <p class="profile-title">Full-Stack Web Developer</p>
            <div class="profile-location">
                <i class="fas fa-map-marker-alt"></i>
                <span>Nairobi, Kenya</span>
            </div>
        </div>
        
        <div class="nav-scrollable-content">
            <ul>
                <li>
                    <a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-home"></i></span>
                        <span class="nav-text">Home</span>
                    </a>
                </li>
               
                <li>
                    <a href="projects.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'projects.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-project-diagram"></i></span>
                        <span class="nav-text">Projects</span>
                        <span style="margin-left: auto; background: var(--accent); color: var(--dark); font-size: 0.7rem; padding: 2px 6px; border-radius: 10px;">5+</span>
                    </a>
                </li>
                <li>
                     <li>
                    <a href="skills.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'skills.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-laptop-code"></i></span>
                        <span class="nav-text">Skills & Tech</span>
                    </a>
                </li>
                    <a href="about_me.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-user-tie"></i></span>
                        <span class="nav-text">About Me</span>
                    </a>
                </li>
               
                <li>
                    <a href="contact.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : ''; ?>">
                        <span class="nav-icon"><i class="fas fa-envelope-open-text"></i></span>
                        <span class="nav-text">Contact</span>
                    </a>
                </li>
            
            </ul>
        </div>
        
        <div class="social-links-bottom">
            <a href="https://github.com/Harrisonkamau" target="_blank" title="GitHub Profile">
                <i class="fab fa-github"></i>
            </a>
            <a href="https://linkedin.com/in/harrison-makau" target="_blank" title="LinkedIn Profile">
                <i class="fab fa-linkedin"></i>
            </a>
            <a href="https://twitter.com/HarrisonMakau14" target="_blank" title="Twitter Profile">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="#" title="CodePen Profile">
                <i class="fab fa-codepen"></i>
            </a>
        </div>
    </nav>

   
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const sideNav = document.getElementById('sideNav');
            const mainContent = document.getElementById('mainContent');
            const navOverlay = document.getElementById('navOverlay');
            
            // Function to toggle navigation
            function toggleNav() {
                const isOpen = sideNav.classList.contains('open');
                if (isOpen) {
                    sideNav.classList.remove('open');
                    navOverlay.classList.remove('active');
                    navToggle.classList.remove('active');
                    if (window.innerWidth >= 992) {
                        mainContent.classList.remove('shifted');
                    }
                    document.body.style.overflow = '';
                } else {
                    sideNav.classList.add('open');
                    navOverlay.classList.add('active');
                    navToggle.classList.add('active');
                    if (window.innerWidth >= 992) {
                        mainContent.classList.add('shifted');
                    }
                    document.body.style.overflow = 'hidden';
                }
            }
            
            navToggle.addEventListener('click', toggleNav);
            
            // Close nav when clicking overlay
            navOverlay.addEventListener('click', toggleNav);
            
            // Close nav when clicking a link on mobile
            if (window.innerWidth < 992) {
                document.querySelectorAll('.side-nav a').forEach(link => {
                    link.addEventListener('click', function(event) {
                        if (!this.classList.contains('active')) {
                             toggleNav();
                        } else {
                            toggleNav();
                        }
                    });
                });
            }
            
            // Highlight active page
            const currentPage = '<?php echo basename($_SERVER['PHP_SELF']); ?>';
            document.querySelectorAll('.side-nav a').forEach(link => {
                if (link.getAttribute('href') && link.getAttribute('href').startsWith(currentPage)) {
                    link.classList.add('active');
                }
            });
            
            // Responsive adjustments on resize
            window.addEventListener('resize', function() {
                if (window.innerWidth >= 992) {
                    sideNav.classList.add('open');
                    navOverlay.classList.remove('active');
                    navToggle.classList.remove('active');
                    mainContent.classList.add('shifted');
                    document.body.style.overflow = '';
                } else {
                    sideNav.classList.remove('open');
                    navOverlay.classList.remove('active');
                    navToggle.classList.remove('active');
                    mainContent.classList.remove('shifted');
                    document.body.style.overflow = '';
                }
            });

            // Initial setup for desktop view if applicable
            if (window.innerWidth >= 992) {
                sideNav.classList.add('open');
                mainContent.classList.add('shifted');
            }

            // Removed the adjustMainContent function and its calls.
            // The body padding-top now handles the fixed header offset.
        });
    </script>
</body>
</html>
