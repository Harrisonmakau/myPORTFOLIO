<?php
// Start session and include database connection
session_start();
require_once 'config.php'; // You'll need to create this file with your DB connection

// Initialize variables
$errors = [];
$success = false;

// Form submission handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);
    $rating = intval($_POST['rating']);
    $is_public = isset($_POST['is_public']) ? 1 : 0;

    // Validation
    if (empty($name)) {
        $errors['name'] = "Name is required";
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Valid email is required";
    }
    if (empty($subject)) {
        $errors['subject'] = "Subject is required";
    } elseif (strlen($subject) > 50) {
        $errors['subject'] = "Subject must be 50 characters or less";
    }
    if (empty($message)) {
        $errors['message'] = "Feedback message is required";
    }
    if ($rating < 1 || $rating > 5) {
        $errors['rating'] = "Please select a valid rating (1-5)";
    }

    // If no errors, insert into database
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("INSERT INTO feedback 
                                  (name, email, subject, message, rating, is_public) 
                                  VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssii", $name, $email, $subject, $message, $rating, $is_public);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $success = true;
                // Clear form fields
                $_POST = [];
            }
            $stmt->close();
        } catch (Exception $e) {
            $errors['database'] = "Error submitting feedback: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KCRH - Feedback Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f9fbfd;
            color: #333;
            line-height: 1.6;
            padding-top: 0;
        }


        .feedback-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            position: relative;
            margin-top: 250px;
        }

        .feedback-title {
            text-align: center;
            margin-bottom: 30px;
            color: #005b94;
            font-size: 2rem;
            font-weight: 600;
        }

        .feedback-title::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, #005b94, #ff6b00);
            margin: 15px auto 0;
            border-radius: 2px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #005b94;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            border-color: #005b94;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0,91,148,0.1);
        }

        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }

        .rating-container {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .rating-container input[type="radio"] {
            display: none;
        }

        .rating-container label {
            font-size: 1.5rem;
            color: #ddd;
            cursor: pointer;
            transition: color 0.3s;
        }

        .rating-container input[type="radio"]:checked ~ label,
        .rating-container label:hover,
        .rating-container label:hover ~ label {
            color: #ff6b00;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .checkbox-group input {
            width: auto;
        }

        .btn-submit {
            background-color: #ff6b00;
            color: white;
            border: none;
            padding: 14px 35px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s;
            display: block;
            margin: 30px auto 0;
            width: fit-content;
        }

        .btn-submit:hover {
            background-color: #e05d00;
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255,107,0,0.4);
        }

        .error-message {
            color: #e63946;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .success-message {
            background-color: #2a9d8f;
            color: white;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }

       

        .back-to-index-button:hover {
            background-color: #004a7a;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            body {
                padding-top: 130px;
            }

            .feedback-container {
                padding: 20px;
                margin: 20px;
            }

            .feedback-title {
                font-size: 1.5rem;
            }

            .back-to-index-button {
                top: 15px;
                left: 15px;
                padding: 8px 12px;
                font-size: 0.8rem;
            }
        }
        .site-footer {
  
    color: black;
    padding: 20px 0;
    font-family: 'Arial', sans-serif;
    margin-top: 40px;
}

.copyright {
    text-align: center;
    font-size: 14px;
}
    </style>
</head>
<body>
    
    
    <div class="feedback-container">
       

        <h2 class="feedback-title">Share Your Feedback</h2>

        <?php if ($success): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i> Thank you for your feedback! It has been submitted successfully.
            </div>
        <?php endif; ?>

        <?php if (!empty($errors['database'])): ?>
            <div class="error-message" style="text-align: center; margin-bottom: 20px;">
                <i class="fas fa-exclamation-circle"></i> <?php echo $errors['database']; ?>
            </div>
        <?php endif; ?>

        <form action="feedback.php" method="POST">
            <div class="form-group">
                <label for="name">Your Name</label>
                <input type="text" id="name" name="name" class="form-control"
                       value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required maxlength="100">
                <?php if (!empty($errors['name'])): ?>
                    <span class="error-message"><?php echo $errors['name']; ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="email">Your Email</label>
                <input type="email" id="email" name="email" class="form-control"
                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required maxlength="100">
                <?php if (!empty($errors['email'])): ?>
                    <span class="error-message"><?php echo $errors['email']; ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="subject">Subject</label>
                <input type="text" id="subject" name="subject" class="form-control"
                       value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>" required maxlength="50">
                <?php if (!empty($errors['subject'])): ?>
                    <span class="error-message"><?php echo $errors['subject']; ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Your Rating (1-5 stars)</label>
                <div class="rating-container">
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <input type="radio" id="star<?php echo $i; ?>" name="rating" value="<?php echo $i; ?>"
                               <?php echo (isset($_POST['rating']) && $_POST['rating'] == $i) ? 'checked' : ''; ?>
                               <?php echo $i == 5 ? 'required' : ''; ?>>
                        <label for="star<?php echo $i; ?>">★</label>
                    <?php endfor; ?>
                </div>
                <?php if (!empty($errors['rating'])): ?>
                    <span class="error-message"><?php echo $errors['rating']; ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="message">Your Feedback</label>
                <textarea id="message" name="message" class="form-control" required><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                <?php if (!empty($errors['message'])): ?>
                    <span class="error-message"><?php echo $errors['message']; ?></span>
                <?php endif; ?>
            </div>

            <div class="checkbox-group">
                <input type="checkbox" id="is_public" name="is_public" value="1"
                       <?php echo (isset($_POST['is_public']) && $_POST['is_public'] == 1) ? 'checked' : ''; ?>>
                <label for="is_public">Display my feedback publicly (without personal information)</label>
            </div>

            <button type="submit" class="btn-submit">Submit Feedback <i class="fas fa-paper-plane"></i></button>
        </form>
    </div>
<footer class="site-footer">
    <div class="copyright">
        <p>Designed and developed by Harrison Makau - 0769638211</p>
        <p>harrisonmakau2022@gmail.com</p>
        &copy; <?php echo date('Y'); ?> Kitui County Referral Hospital. All Rights Reserved.
    </div>
</footer>
    <script>
        // Back to top functionality
        document.addEventListener('DOMContentLoaded', function() {
            const backToTop = document.createElement('div');
            backToTop.className = 'back-to-top';
            backToTop.id = 'backToTop';
            backToTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
            document.body.appendChild(backToTop);

            window.addEventListener('scroll', function() {
                if (window.scrollY > 300) {
                    backToTop.classList.add('active');
                } else {
                    backToTop.classList.remove('active');
                }
            });

            backToTop.addEventListener('click', () => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>