<?php
$featuredProjects = [
    [
        'title' => 'EasyGari Agent Portal',
        'description' => 'Professional portal for vehicle financing specialist George Odiwuor featuring loan management and client services.',
        'image' => 'images/Screenshot 2025-07-15 220249.png',
        'technologies' => ['PHP', 'MySQL', 'JavaScript', 'HTML', 'CSS3', 'BootStrap'],
        'link' => 'https://www.george-easygari.co.ke'
    ],
    [
        'title' => 'DriveDirect Booking',
        'description' => 'Final year project featuring a secure bus ticket booking system with admin panel and user management.',
        'image' => 'images/Screenshot 2025-07-15 223138.png',
        'technologies' => ['MySQL', 'JavaScript', 'CSS3', 'PHP'],
        'link' => 'https://harrison.lovestoblog.com'
    ],
   
];

$upcomingProjects = [
    [
        'title' => 'E-Commerce Platform',
        'description' => 'Full-featured online store with product management, shopping cart, and payment gateway integration.',
        'technologies' => ['React', 'Node.js', 'MongoDB']
    ],
    [
        'title' => 'School Management System',
        'description' => 'Comprehensive system for student records, attendance, exams, and performance tracking.',
        'technologies' => ['Laravel', 'MySQL', 'Vue.js']
    ],
    // Moved from featuredProjects
    [
        'title' => 'Kitui Hospital Portal',
        'description' => 'Professional attachment management system for healthcare, ICT, and HR students at Kenya\'s leading referral hospital.',
        'image' => 'images/kitui-hospital-screenshot.png', // Original image from featured
        'technologies' => ['PHP', 'jQuery', 'HTML5']
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harrison | Projects</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        /* Define your color variables */
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --light-color: #f8f9fa;
            --accent-color: #e74c3c;

            /* New colors for animated background (from previous turn) */
            --bg-gradient-start: #e0f2f7; /* Light blue */
            --bg-gradient-mid: #e8f9fd;   /* Even lighter blue */
            --bg-gradient-end: #d1e9f1;   /* Slightly darker light blue */
        }
        body {
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
            scroll-behavior: smooth;
            position: relative; /* Needed for pseudo-element positioning */
            background-color: var(--light-color); /* Fallback/base background */
        }

        /* Modern Animated Background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 200%; /* Wider to allow for movement */
            height: 200%; /* Taller to allow for movement */
            background: linear-gradient(135deg, var(--bg-gradient-start), var(--bg-gradient-mid), var(--bg-gradient-end));
            background-size: 400% 400%; /* Larger background to animate */
            animation: gradient-animation 15s ease infinite alternate; /* Slower, smoother animation */
            z-index: -1; /* Send to back */
            filter: blur(80px); /* Soft blur effect */
            opacity: 0.7; /* Subtle transparency */
        }

        @keyframes gradient-animation {
            0% { background-position: 0% 0%; }
            50% { background-position: 100% 100%; }
            100% { background-position: 0% 0%; }
        }

        /* Section Title Styling (from previous turn) */
        .section-title {
            color: var(--secondary-color);
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            position: relative;
            padding-bottom: 0.75rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.05);
        }

        .section-title::after {
            content: '';
            position: absolute;
            left: 50%;
            bottom: 0;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background-color: var(--accent-color);
            border-radius: 2px;
        }

        /* Subtitle Styling (from previous turn) */
        .section-subtitle {
            font-size: 1.15rem;
            color: var(--text-color); /* Assuming text-color is defined in your main file or here */
            margin-top: 0;
            margin-bottom: 3rem;
            font-weight: 400;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
            text-align: center;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.03);
        }

        /* Project Card Specific Styles */
        .project-card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 2rem; /* Add margin between project cards */
            background-color: #ffffff; /* Ensure cards have a white background */
        }

        .project-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
        }

        .project-card img {
            width: 100%;
            height: 200px; /* Fixed height for project images */
            object-fit: contain; /* Changed from 'cover' to 'contain' to prevent cropping */
            background-color: #f0f0f0; /* Add a background color to fill empty space if image is smaller */
            padding: 10px; /* Add some padding around the image inside the fixed height */
        }

        .project-card .card-body {
            padding: 1.5rem;
        }

        .project-card .card-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--secondary-color);
            margin-bottom: 0.75rem;
        }

        .project-card .card-text {
            font-size: 0.95rem;
            color: var(--text-color); /* Assuming text-color is defined */
            line-height: 1.6;
            margin-bottom: 1.25rem;
        }

        .project-card .tech-tags .badge {
            font-size: 0.75rem;
            padding: 0.4em 0.7em;
            border-radius: 0.3rem;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            display: inline-block; /* Ensure badges wrap correctly */
            background-color: var(--primary-color) !important; /* Use primary color for badges */
        }

        .coming-soon {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: var(--accent-color);
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            font-weight: 600;
            z-index: 10;
        }
    </style>
</head>
<body>
    <!-- Navigation (you might want to include this from a shared partial) -->
    
    <!-- Featured Projects -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center section-title animate__animated animate__fadeIn">Featured Projects</h2>
            <p class="text-center section-subtitle animate__animated animate__fadeInUp animate__delay-1s">
                Showcasing my best work and practical application of technical skills.
            </p>
            <div class="row mt-4 justify-content-center"> <!-- Added justify-content-center for alignment -->
                <?php foreach ($featuredProjects as $project): ?>
                <div class="col-md-4 animate__animated animate__fadeInUp">
                    <div class="project-card card">
                        <img src="<?= $project['image'] ?>" class="card-img-top" alt="<?= $project['title'] ?>" onerror="this.onerror=null;this.src='https://placehold.co/600x400/cccccc/333333?text=Image+Not+Found';">
                        <div class="card-body">
                            <h5 class="card-title"><?= $project['title'] ?></h5>
                            <p class="card-text"><?= $project['description'] ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <a href="<?= $project['link'] ?>" class="btn btn-sm btn-outline-primary">View Details <i class="fas fa-external-link-alt ms-1"></i></a>
                                <div class="tech-tags">
                                    <?php foreach ($project['technologies'] as $tech): ?>
                                    <span class="badge bg-primary"><?= $tech ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Projects in Progress (formerly carousel) -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center section-title animate__animated animate__fadeIn">Projects in Progress</h2>
            <p class="text-center section-subtitle animate__animated animate__fadeInUp animate__delay-1s">
                A glimpse into my current endeavors and future-focused development.
            </p>
            <div class="row mt-4 justify-content-center"> <!-- Added justify-content-center for alignment -->
                <?php foreach ($upcomingProjects as $project): ?>
                <div class="col-md-4 animate__animated animate__fadeInUp">
                    <div class="project-card card">
                        <div class="position-relative">
                            <img src="images/coming-soon.jpg" class="card-img-top" alt="Project Coming Soon" onerror="this.onerror=null;this.src='https://placehold.co/600x400/cccccc/333333?text=Coming+Soon';">
                            <span class="coming-soon">Coming Soon</span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?= $project['title'] ?></h5>
                            <p class="card-text"><?= $project['description'] ?></p>
                            <div class="tech-tags">
                                <?php foreach ($project['technologies'] as $tech): ?>
                                <span class="badge bg-primary"><?= $tech ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Initialize animations and other scripts
        $(document).ready(function() {
            // Animate elements when they come into view
            function animateOnScroll() {
                $('.animate__animated').each(function() {
                    var elementPos = $(this).offset().top;
                    var topOfWindow = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    
                    if (elementPos < topOfWindow + windowHeight - 100) {
                        // Check if the element has an animation class and hasn't been animated yet
                        if ($(this).attr('class').includes('animate__') && !$(this).hasClass('animate__visible')) {
                            var animationClass = $(this).attr('class').split('animate__animated ')[1].split(' ')[0];
                            $(this).addClass(animationClass);
                            $(this).addClass('animate__visible'); // Mark as animated
                        }
                    }
                });
            }

            // Run on load and scroll
            animateOnScroll();
            $(window).scroll(function() {
                animateOnScroll();
            });
        });
    </script>
</body>
</html>
