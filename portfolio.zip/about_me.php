<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me | Professional Portfolio</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a0ca3;
            --accent: #f72585;
            --secondary: #7209b7;
            --dark: #1a1a2e;
            --light: #f8f9fa;
            --card-bg: rgba(255, 255, 255, 0.9);
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light);
            color: var(--dark);
            margin: 0;
            padding: 0;
        }
        
        .portfolio-container {
            width: 1075px;
          
            margin: 0 auto 0 200px;
            padding: 20px;
            box-sizing: border-box;
        }
        
        .main-content-wrapper {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            margin-left: 100px;
        }
        
        .about-section {
            padding: 5rem 0;
            position: relative;
            overflow: hidden;
        }
        
        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 3rem;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 2rem;
        }
        
        .timeline-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
            position: relative;
            border-left: 5px solid var(--primary);
            transition: transform 0.3s ease;
        }
        
        .timeline-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
        }
        
        .skill-badge {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            margin: 0.3rem;
            display: inline-block;
            font-size: 0.9rem;
            box-shadow: 0 4px 10px rgba(67, 97, 238, 0.2);
        }
        
        .tree-container {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            margin-top: 3rem;
        }
        
        #skillsTree {
            width: 100%;
            height: 500px;
            border-radius: 10px;
        }
        
        .education-icon {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }
        
        .floating-shapes {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }
        
        .shape {
            position: absolute;
            opacity: 0.1;
            animation: float 15s infinite linear;
        }
        
        @keyframes float {
            0% { transform: translateY(0) rotate(0deg); }
            100% { transform: translateY(-100vh) rotate(360deg); }
        }

        @media (max-width: 768px) {
            .main-content-wrapper {
                margin-left: 0;
            }
            
            .section-title {
                font-size: 2.2rem;
            }
            
            .about-section {
                padding: 3rem 0;
            }
        }
    </style>
</head>
<body>
    <?php include 'nav.php';?>
    <div class="portfolio-container">
        <div class="main-content-wrapper">
            <section class="about-section">
                <div class="floating-shapes">
                    <div class="shape" style="top: 10%; left: 5%; font-size: 3rem; animation-duration: 20s;">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <div class="shape" style="top: 30%; left: 80%; font-size: 4rem; animation-duration: 25s; animation-delay: 5s;">
                        <i class="fas fa-laptop-code"></i>
                    </div>
                    <div class="shape" style="top: 70%; left: 15%; font-size: 2.5rem; animation-duration: 18s; animation-delay: 3s;">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                </div>
                
                <div class="container">
                    <div class="text-center mb-5">
                        <h1 class="section-title">My Journey</h1>
                    </div>
                    
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="timeline-card">
                                <div class="education-icon text-center">
                                    <i class="fas fa-university"></i>
                                </div>
                                <h3>Bachelor of Business Information Technology (BBIT)</h3>
                                <p class="text-muted">Mount Kenya University (MKU), Thika Main Campus</p>
                                <p>I graduated with a BBIT degree that provided me with a strong foundation in both business and technology, equipping me with the skills to bridge the gap between these two critical domains.</p>
                            </div>
                            
                            <div class="timeline-card">
                                <div class="education-icon text-center">
                                    <i class="fas fa-user-graduate"></i>
                                </div>
                                <h3>Current Studies</h3>
                                <p>Currently pursuing advanced certifications in:</p>
                                <ul>
                                    <li>Cybersecurity Fundamentals (CISCO)</li>
                                    <li>Network Engineering (CISCO)</li>
                                    <li>Web Application Security</li>
                                </ul>
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="timeline-card">
                                <div class="education-icon text-center">
                                    <i class="fas fa-fire"></i>
                                </div>
                                <h3>My Passion</h3>
                                <p>I'm deeply passionate about web development and cybersecurity, constantly exploring the intersection between creating beautiful, functional web experiences and ensuring they're secure and robust.</p>
                                <p>My approach combines aesthetic design with technical excellence, always focusing on creating solutions that deliver real value.</p>
                            </div>
                            
                            <div class="timeline-card">
                                <div class="education-icon text-center">
                                    <i class="fas fa-tools"></i>
                                </div>
                                <h3>Technical Skills</h3>
                                <div class="mt-3">
                                    <span class="skill-badge" style="background: #e34f26;">HTML5</span>
                                    <span class="skill-badge" style="background: #2965f1;">CSS3</span>
                                    <span class="skill-badge" style="background: #7952b3;">Bootstrap</span>
                                    <span class="skill-badge" style="background: #f7df1e; color: #000;">JavaScript</span>
                                    <span class="skill-badge" style="background: #0769AD;">jQuery</span>
                                    <span class="skill-badge" style="background: #777bb4;">PHP</span>
                                    <span class="skill-badge" style="background: #4479a1;">MySQL</span>
                                    <span class="skill-badge" style="background: #000;">Networking</span>
                                    <span class="skill-badge" style="background: #ff6b6b;">Cybersecurity</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Interactive Tree Diagram Section -->
                    <div class="tree-container">
                        <h3 class="text-center mb-4">My Skills Development Path</h3>
                        <div id="skillsTree"></div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <script>
        // Generate floating shapes dynamically
        document.addEventListener('DOMContentLoaded', function() {
            const container = document.querySelector('.floating-shapes');
            const icons = ['fa-code', 'fa-server', 'fa-network-wired', 'fa-lock', 'fa-database'];
            
            for (let i = 0; i < 6; i++) {
                const shape = document.createElement('div');
                shape.className = 'shape';
                shape.innerHTML = `<i class="fas ${icons[Math.floor(Math.random() * icons.length)]}"></i>`;
                
                shape.style.left = `${Math.random() * 90}%`;
                shape.style.top = `${Math.random() * 90}%`;
                shape.style.fontSize = `${2 + Math.random() * 3}rem`;
                shape.style.animationDuration = `${15 + Math.random() * 15}s`;
                shape.style.animationDelay = `${Math.random() * 10}s`;
                
                container.appendChild(shape);
            }
            
            // Create interactive tree diagram
            createSkillsTree();
        });
        
        function createSkillsTree() {
            const data = {
                name: "My Skills",
                children: [
                    {
                        name: "Education",
                        children: [
                            { name: "BBIT Degree", value: 5 },
                            { name: "Business Fundamentals", value: 4 },
                            { name: "IT Management", value: 4 }
                        ]
                    },
                    {
                        name: "Web Development",
                        children: [
                            { name: "HTML/CSS", value: 9 },
                            { name: "JavaScript", value: 8 },
                            { name: "PHP/MySQL", value: 8 },
                            { name: "Bootstrap", value: 8 }
                        ]
                    },
                    {
                        name: "Cybersecurity",
                        children: [
                            { name: "Network Security", value: 6 },
                            { name: "CISCO Courses", value: 7 },
                            { name: "Web Security", value: 6 }
                        ]
                    },
                    {
                        name: "Soft Skills",
                        children: [
                            { name: "Problem Solving", value: 8 },
                            { name: "Team Collaboration", value: 7 },
                            { name: "Project Management", value: 6 }
                        ]
                    }
                ]
            };
            
            const width = document.getElementById('skillsTree').clientWidth;
            const height = 500;
            
            const svg = d3.select("#skillsTree")
                .append("svg")
                .attr("width", width)
                .attr("height", height)
                .append("g")
                .attr("transform", `translate(${width/2}, 50)`);
            
            const root = d3.hierarchy(data);
            const treeLayout = d3.tree().size([2 * Math.PI, Math.min(width, height) / 2 - 50]);
            
            treeLayout(root);
            
            // Add links
            svg.append("g")
                .selectAll("path")
                .data(root.links())
                .enter()
                .append("path")
                .attr("d", d3.linkRadial()
                    .angle(d => d.x)
                    .radius(d => d.y))
                .attr("fill", "none")
                .attr("stroke", "#4361ee")
                .attr("stroke-opacity", 0.4)
                .attr("stroke-width", 1.5);
            
            // Add nodes
            const node = svg.append("g")
                .selectAll("g")
                .data(root.descendants())
                .enter()
                .append("g")
                .attr("transform", d => `
                    rotate(${d.x * 180 / Math.PI - 90})
                    translate(${d.y},0)
                `);
            
            node.append("circle")
                .attr("r", d => d.data.value ? d.data.value * 1.5 : 5)
                .attr("fill", d => {
                    if (d.depth === 0) return "#3a0ca3";
                    if (d.depth === 1) return "#4361ee";
                    return "#f72585";
                })
                .attr("stroke", "#fff")
                .attr("stroke-width", 2)
                .on("mouseover", function() {
                    d3.select(this).attr("stroke", "#000");
                })
                .on("mouseout", function() {
                    d3.select(this).attr("stroke", "#fff");
                });
            
            node.append("text")
                .attr("dy", "0.31em")
                .attr("x", d => d.x < Math.PI ? 8 : -8)
                .attr("text-anchor", d => d.x < Math.PI ? "start" : "end")
                .attr("transform", d => d.x >= Math.PI ? "rotate(180)" : null)
                .text(d => d.data.name)
                .attr("font-size", "12px")
                .attr("fill", "#333");
        }
    </script>
</body>
</html>